import { useEffect, useState, useRef } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import Navigation from './sections/Navigation';
import Hero from './sections/Hero';
import Modules from './sections/Modules';
import LearningPath from './sections/LearningPath';
import ReadingSection from './sections/ReadingSection';
import GrammarSection from './sections/GrammarSection';
import VocabularySection from './sections/VocabularySection';
import ListeningSection from './sections/ListeningSection';
import SpeakingSection from './sections/SpeakingSection';
import Testimonials from './sections/Testimonials';
import Footer from './sections/Footer';
import Dashboard from './sections/Dashboard';
import { UserProgressProvider } from './hooks/useUserProgress';
import { Toaster } from '@/components/ui/sonner';

gsap.registerPlugin(ScrollTrigger);

function App() {
  const [currentView, setCurrentView] = useState<'home' | 'dashboard' | 'reading' | 'grammar' | 'vocabulary' | 'listening' | 'speaking'>('home');
  const mainRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Smooth scroll to top when view changes
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, [currentView]);

  const renderView = () => {
    switch (currentView) {
      case 'dashboard':
        return <Dashboard onNavigate={setCurrentView} />;
      case 'reading':
        return <ReadingSection onBack={() => setCurrentView('dashboard')} />;
      case 'grammar':
        return <GrammarSection onBack={() => setCurrentView('dashboard')} />;
      case 'vocabulary':
        return <VocabularySection onBack={() => setCurrentView('dashboard')} />;
      case 'listening':
        return <ListeningSection onBack={() => setCurrentView('dashboard')} />;
      case 'speaking':
        return <SpeakingSection onBack={() => setCurrentView('dashboard')} />;
      default:
        return (
          <>
            <Hero onStart={() => setCurrentView('dashboard')} />
            <Modules onSelectModule={setCurrentView} />
            <LearningPath />
            <Testimonials />
          </>
        );
    }
  };

  return (
    <UserProgressProvider>
      <div ref={mainRef} className="relative min-h-screen bg-slate-50">
        {/* Grain overlay */}
        <div className="grain-overlay" />
        
        {/* Navigation */}
        <Navigation 
          currentView={currentView} 
          onNavigate={setCurrentView} 
        />
        
        {/* Main content */}
        <main className="relative">
          {renderView()}
        </main>
        
        {/* Footer - only show on home */}
        {currentView === 'home' && <Footer />}
        
        {/* Toast notifications */}
        <Toaster position="top-center" richColors />
      </div>
    </UserProgressProvider>
  );
}

export default App;
