// Dashboard component - no state needed
import { motion } from 'framer-motion';
import {
  BookOpen,
  PenTool,
  Headphones,
  MessageCircle,
  Sparkles,
  Flame,
  Trophy,
  Clock,
  Star,
  Zap,
  RotateCcw,
  Target,
} from 'lucide-react';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { useUserProgress } from '@/hooks/useUserProgress';
import { toast } from 'sonner';

interface DashboardProps {
  onNavigate: (view: 'reading' | 'grammar' | 'vocabulary' | 'listening' | 'speaking') => void;
}

const dailyGoals = [
  { id: 1, title: 'Complete 2 lessons', current: 1, target: 2, xp: 20 },
  { id: 2, title: 'Practice vocabulary', current: 0, target: 1, xp: 15 },
  { id: 3, title: 'Listen to audio', current: 1, target: 1, xp: 10, completed: true },
];

const recentAchievements = [
  { id: 1, title: 'First Steps', description: 'Complete your first lesson', icon: Star },
  { id: 2, title: 'Week Warrior', description: '7-day learning streak', icon: Flame },
  { id: 3, title: 'Word Master', description: 'Learn 100 new words', icon: Sparkles },
];

const learningModules = [
  {
    id: 'reading' as const,
    title: 'Reading',
    description: 'Comprehension & Stories',
    icon: BookOpen,
    color: 'from-purple-500 to-purple-700',
    bgColor: 'bg-purple-50',
    progress: 65,
    lessonsToday: 2,
  },
  {
    id: 'grammar' as const,
    title: 'Grammar',
    description: 'Rules & Writing',
    icon: PenTool,
    color: 'from-blue-500 to-blue-700',
    bgColor: 'bg-blue-50',
    progress: 40,
    lessonsToday: 1,
  },
  {
    id: 'vocabulary' as const,
    title: 'Vocabulary',
    description: 'Words & Flashcards',
    icon: Sparkles,
    color: 'from-green-500 to-emerald-600',
    bgColor: 'bg-green-50',
    progress: 80,
    lessonsToday: 3,
  },
  {
    id: 'listening' as const,
    title: 'Listening',
    description: 'Audio & Comprehension',
    icon: Headphones,
    color: 'from-yellow-500 to-orange-500',
    bgColor: 'bg-yellow-50',
    progress: 30,
    lessonsToday: 1,
  },
  {
    id: 'speaking' as const,
    title: 'Speaking',
    description: 'Pronunciation & Practice',
    icon: MessageCircle,
    color: 'from-pink-500 to-rose-600',
    bgColor: 'bg-pink-50',
    progress: 20,
    lessonsToday: 0,
  },
];

export default function Dashboard({ onNavigate }: DashboardProps) {
  const { progress, resetProgress } = useUserProgress();

  const totalXP = progress.xp;
  const nextLevelXP = 1000;
  const xpProgress = Math.min((totalXP / nextLevelXP) * 100, 100);
  const lessonsProgress = Math.min((progress.lessonsCompleted / progress.totalLessons) * 100, 100);

  const handleReset = () => {
    resetProgress();
    toast.success('Progreso reiniciado.');
  };

  return (
    <div className="min-h-screen bg-slate-50 pt-24 pb-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Welcome Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="mb-8"
        >
          <div className="flex flex-col gap-4 md:flex-row md:items-start md:justify-between">
            <div>
              <h1 className="text-3xl sm:text-4xl font-bold text-slate-800 mb-2">
                Welcome back, <span className="gradient-text">Learner!</span>
              </h1>
              <p className="text-slate-600">
                Ready to continue your English journey? You are doing great.
              </p>
            </div>
            <Button
              variant="outline"
              onClick={handleReset}
              className="rounded-full border-slate-200 text-slate-600 hover:bg-slate-100"
            >
              <RotateCcw className="w-4 h-4 mr-2" />
              Reset progress
            </Button>
          </div>
        </motion.div>

        {/* Stats Row */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5, delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
        >
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-orange-100 rounded-xl flex items-center justify-center">
                <Flame className="w-5 h-5 text-orange-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-800">{progress.streak}</div>
                <div className="text-xs text-slate-500">Day Streak</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-xl flex items-center justify-center">
                <Zap className="w-5 h-5 text-purple-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-800">{totalXP}</div>
                <div className="text-xs text-slate-500">Total XP</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-yellow-100 rounded-xl flex items-center justify-center">
                <Trophy className="w-5 h-5 text-yellow-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-800">{progress.achievements.length}</div>
                <div className="text-xs text-slate-500">Achievements</div>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-2xl p-4 shadow-sm border border-slate-100">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-blue-100 rounded-xl flex items-center justify-center">
                <Clock className="w-5 h-5 text-blue-600" />
              </div>
              <div>
                <div className="text-2xl font-bold text-slate-800">12h</div>
                <div className="text-xs text-slate-500">Time Spent</div>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Main Content - Learning Modules */}
          <div className="lg:col-span-2 space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-slate-800">Learning Modules</h2>
                <span className="text-sm text-slate-500">
                  Level: <span className="font-semibold text-purple-600">{progress.level}</span>
                </span>
              </div>

              <div className="grid sm:grid-cols-2 gap-4">
                {learningModules.map((module, index) => {
                  const Icon = module.icon;
                  return (
                    <motion.div
                      key={module.id}
                      initial={{ opacity: 0, scale: 0.9 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.4, delay: 0.1 * index }}
                      whileHover={{ scale: 1.02, y: -4 }}
                      onClick={() => onNavigate(module.id)}
                      className={`${module.bgColor} rounded-2xl p-5 cursor-pointer transition-all duration-300 hover:shadow-lg group`}
                    >
                      <div className="flex items-start justify-between mb-3">
                        <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${module.color} flex items-center justify-center`}>
                          <Icon className="w-6 h-6 text-white" />
                        </div>
                        <div className="flex items-center gap-1 text-sm text-slate-600">
                          <Clock className="w-4 h-4" />
                          <span>{module.lessonsToday} today</span>
                        </div>
                      </div>

                      <h3 className="font-bold text-slate-800 mb-1">{module.title}</h3>
                      <p className="text-sm text-slate-600 mb-3">{module.description}</p>

                      <div className="flex items-center gap-3">
                        <div className="flex-1">
                          <div className="h-2 bg-white/50 rounded-full overflow-hidden">
                            <div
                              className={`h-full bg-gradient-to-r ${module.color} transition-all duration-500`}
                              style={{ width: `${module.progress}%` }}
                            />
                          </div>
                        </div>
                        <span className="text-xs font-semibold text-slate-600">{module.progress}%</span>
                      </div>
                    </motion.div>
                  );
                })}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100"
            >
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h2 className="text-xl font-bold text-slate-800">Your real progress</h2>
                  <p className="text-sm text-slate-500">Based on saved app state, not placeholders.</p>
                </div>
                <Target className="w-6 h-6 text-purple-600" />
              </div>

              <div className="space-y-4">
                <div>
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-slate-600">XP toward next level</span>
                    <span className="font-medium text-slate-800">{Math.round(xpProgress)}%</span>
                  </div>
                  <Progress value={xpProgress} className="h-2" />
                </div>

                <div>
                  <div className="flex items-center justify-between text-sm mb-2">
                    <span className="text-slate-600">Lessons completed</span>
                    <span className="font-medium text-slate-800">
                      {progress.lessonsCompleted}/{progress.totalLessons}
                    </span>
                  </div>
                  <Progress value={lessonsProgress} className="h-2" />
                </div>

                <div className="grid sm:grid-cols-3 gap-3 pt-2">
                  <div className="rounded-2xl bg-slate-50 p-4">
                    <div className="text-xs text-slate-500 mb-1">Current level</div>
                    <div className="text-lg font-bold text-slate-800">{progress.level}</div>
                  </div>
                  <div className="rounded-2xl bg-slate-50 p-4">
                    <div className="text-xs text-slate-500 mb-1">Last activity</div>
                    <div className="text-lg font-bold text-slate-800">
                      {progress.lastActiveDate ? 'Saved' : 'No data'}
                    </div>
                  </div>
                  <div className="rounded-2xl bg-slate-50 p-4">
                    <div className="text-xs text-slate-500 mb-1">Achievements</div>
                    <div className="text-lg font-bold text-slate-800">{progress.achievements.length}</div>
                  </div>
                </div>
              </div>
            </motion.div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.3 }}
              className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-slate-800">Daily Goals</h2>
                <Clock className="w-5 h-5 text-slate-400" />
              </div>
              <div className="space-y-4">
                {dailyGoals.map((goal) => (
                  <div key={goal.id} className="space-y-2">
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-700">{goal.title}</span>
                      <span className="text-slate-500">
                        {goal.current}/{goal.target}
                      </span>
                    </div>
                    <Progress value={(goal.current / goal.target) * 100} className="h-2" />
                  </div>
                ))}
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
              className="bg-white rounded-3xl p-6 shadow-sm border border-slate-100"
            >
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-lg font-bold text-slate-800">Achievements</h2>
                <Trophy className="w-5 h-5 text-yellow-500" />
              </div>
              <div className="space-y-3">
                {recentAchievements.slice(0, 3).map((achievement) => {
                  const Icon = achievement.icon;
                  return (
                    <div key={achievement.id} className="flex items-start gap-3">
                      <div className="w-9 h-9 rounded-xl bg-slate-100 flex items-center justify-center shrink-0">
                        <Icon className="w-4 h-4 text-slate-600" />
                      </div>
                      <div>
                        <div className="font-semibold text-slate-800 text-sm">{achievement.title}</div>
                        <div className="text-xs text-slate-500">{achievement.description}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}
