import { useRef } from 'react';
import { motion } from 'framer-motion';
import { BookOpen, PenTool, Headphones, Sparkles, ArrowRight } from 'lucide-react';

interface ModulesProps {
  onSelectModule: (module: 'reading' | 'grammar' | 'vocabulary' | 'listening' | 'speaking') => void;
}

const modules = [
  {
    id: 'reading' as const,
    title: 'Reading Comprehension',
    description: 'Dive into engaging stories, articles, and passages. Test your understanding with interactive quizzes and expand your knowledge.',
    icon: BookOpen,
    color: 'from-purple-500 to-purple-700',
    bgColor: 'bg-purple-50',
    iconBg: 'bg-purple-100',
    features: ['Short Stories', 'News Articles', 'Comprehension Quizzes', 'Word Meanings'],
  },
  {
    id: 'grammar' as const,
    title: 'Grammar & Writing',
    description: 'Master English grammar rules through interactive lessons. Practice writing and get instant feedback on your progress.',
    icon: PenTool,
    color: 'from-blue-500 to-blue-700',
    bgColor: 'bg-blue-50',
    iconBg: 'bg-blue-100',
    features: ['Tenses & Verbs', 'Sentence Structure', 'Writing Practice', 'Error Correction'],
  },
  {
    id: 'listening' as const,
    title: 'Listening & Speaking',
    description: 'Train your ear with native audio content. Practice pronunciation and improve your conversational skills.',
    icon: Headphones,
    color: 'from-yellow-500 to-orange-500',
    bgColor: 'bg-yellow-50',
    iconBg: 'bg-yellow-100',
    features: ['Native Audio', 'Dialogues', 'Pronunciation', 'Shadowing'],
  },
  {
    id: 'vocabulary' as const,
    title: 'Vocabulary Builder',
    description: 'Learn new words daily with fun games and flashcards. Track your progress and never forget what you learn.',
    icon: Sparkles,
    color: 'from-green-500 to-emerald-600',
    bgColor: 'bg-green-50',
    iconBg: 'bg-green-100',
    features: ['Word Games', 'Flashcards', 'Daily Words', 'Spaced Repetition'],
  },
];

export default function Modules({ onSelectModule }: ModulesProps) {
  const containerRef = useRef<HTMLDivElement>(null);

  return (
    <section ref={containerRef} className="py-20 bg-slate-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 bg-purple-100 text-purple-700 rounded-full text-sm font-semibold mb-4">
            Interactive Learning
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-800 mb-4">
            Explore Our <span className="gradient-text">Learning Modules</span>
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Choose your path and start mastering English with our comprehensive, interactive modules designed for all skill levels.
          </p>
        </motion.div>

        {/* Module Cards Grid */}
        <div className="grid md:grid-cols-2 gap-6 lg:gap-8">
          {modules.map((module, index) => {
            const Icon = module.icon;
            return (
              <motion.div
                key={module.id}
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                whileHover={{ y: -8, scale: 1.02 }}
                onClick={() => onSelectModule(module.id)}
                className={`relative group cursor-pointer ${module.bgColor} rounded-3xl p-6 lg:p-8 overflow-hidden transition-all duration-500 hover:shadow-2xl`}
              >
                {/* Background gradient on hover */}
                <div className={`absolute inset-0 bg-gradient-to-br ${module.color} opacity-0 group-hover:opacity-10 transition-opacity duration-500`} />
                
                {/* Content */}
                <div className="relative z-10">
                  <div className="flex items-start justify-between mb-6">
                    <div className={`w-16 h-16 ${module.iconBg} rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}>
                      <Icon className={`w-8 h-8 text-transparent bg-clip-text bg-gradient-to-br ${module.color}`} style={{ color: 'inherit' }} />
                    </div>
                    <motion.div
                      className="w-10 h-10 rounded-full bg-white/80 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                      whileHover={{ x: 5 }}
                    >
                      <ArrowRight className="w-5 h-5 text-slate-700" />
                    </motion.div>
                  </div>

                  <h3 className="text-2xl font-bold text-slate-800 mb-3 group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-purple-600 group-hover:to-blue-500 transition-all">
                    {module.title}
                  </h3>
                  
                  <p className="text-slate-600 mb-6 leading-relaxed">
                    {module.description}
                  </p>

                  {/* Features */}
                  <div className="flex flex-wrap gap-2">
                    {module.features.map((feature) => (
                      <span
                        key={feature}
                        className="px-3 py-1 bg-white/80 rounded-full text-xs font-medium text-slate-600"
                      >
                        {feature}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Decorative elements */}
                <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-gradient-to-br from-white/40 to-transparent rounded-full blur-2xl group-hover:scale-150 transition-transform duration-700" />
              </motion.div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4 }}
          className="text-center mt-12"
        >
          <p className="text-slate-600 mb-4">
            Not sure where to start? Take our placement test!
          </p>
          <button className="inline-flex items-center gap-2 text-purple-600 font-semibold hover:text-purple-700 transition-colors">
            Take Placement Test
            <ArrowRight className="w-4 h-4" />
          </button>
        </motion.div>
      </div>
    </section>
  );
}
