import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, 
  MessageCircle, 
  Mic, 
  MicOff,
  Play,
  RotateCcw,
  Volume2,
  ChevronRight,
  Lightbulb,
  Trophy,
  Sparkles
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { useUserProgress } from '@/hooks/useUserProgress';

interface SpeakingSectionProps {
  onBack: () => void;
}

interface SpeakingExercise {
  id: number;
  type: 'repeat' | 'read' | 'dialogue' | 'describe';
  title: string;
  instruction: string;
  content: string;
  hint?: string;
  sampleAudio?: string;
}

interface SpeakingLesson {
  id: number;
  title: string;
  level: string;
  description: string;
  exercises: SpeakingExercise[];
}

const speakingLessons: SpeakingLesson[] = [
  {
    id: 1,
    title: 'Basic Pronunciation',
    level: 'A1',
    description: 'Practice essential English sounds and words.',
    exercises: [
      {
        id: 1,
        type: 'repeat',
        title: 'Repeat After Me',
        instruction: 'Listen and repeat the following words. Focus on the pronunciation.',
        content: 'Hello, Thank you, Please, Excuse me, Good morning',
        hint: 'Speak clearly and at a natural pace. Don\'t rush!',
      },
      {
        id: 2,
        type: 'read',
        title: 'Read Aloud',
        instruction: 'Read this short passage out loud. Try to be natural and fluent.',
        content: 'My name is Anna. I am from Spain. I live in a small apartment in Madrid. I work as a teacher. I love my job because I enjoy helping students learn new things.',
        hint: 'Pay attention to the rhythm and intonation of sentences.',
      },
      {
        id: 3,
        type: 'dialogue',
        title: 'Practice Dialogue',
        instruction: 'Read the part of the Customer in this dialogue.',
        content: `Waiter: Good evening! Welcome to our restaurant. Do you have a reservation?
Customer: Good evening! Yes, I have a reservation for two people. The name is Smith.
Waiter: Perfect, Mr. Smith. Right this way, please. Here is your table.
Customer: Thank you. Could I see the menu, please?
Waiter: Of course. Here you are. I'll give you a moment to look it over.`,
        hint: 'Try to sound polite and friendly, like you\'re really at a restaurant!',
      },
    ],
  },
  {
    id: 2,
    title: 'Daily Conversations',
    level: 'A2',
    description: 'Practice common everyday conversations.',
    exercises: [
      {
        id: 1,
        type: 'describe',
        title: 'Describe the Picture',
        instruction: 'Look at the description below and describe what you see in your own words.',
        content: 'A busy city street with people walking, cars driving, tall buildings, a coffee shop on the corner, and a park across the street. The weather is sunny and warm.',
        hint: 'Use descriptive adjectives and try to create a clear picture with your words.',
      },
      {
        id: 2,
        type: 'dialogue',
        title: 'Making Plans',
        instruction: 'Practice this conversation about making weekend plans.',
        content: `Friend A: Hey! What are you doing this weekend?
Friend B: I'm not sure yet. I was thinking about going to the movies. Want to join?
Friend A: That sounds great! What movie do you want to see?
Friend B: How about that new action film? It got really good reviews.
Friend A: Perfect! What time works for you?
Friend B: Is Saturday evening okay? Around 7 PM?`,
        hint: 'Pay attention to question intonation - your voice should rise at the end of questions.',
      },
    ],
  },
];

// Simulated speech recognition
const useSpeechRecognition = () => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const startListening = () => {
    setIsListening(true);
    setTranscript('');
    setInterimTranscript('');
    
    // Simulate speech recognition with random progress
    let simulatedText = '';
    const words = ['hello', 'thank', 'you', 'please', 'good', 'morning', 'my', 'name', 'is', 'I', 'am', 'from'];
    
    intervalRef.current = setInterval(() => {
      if (Math.random() > 0.3) {
        const word = words[Math.floor(Math.random() * words.length)];
        simulatedText += word + ' ';
        setInterimTranscript(simulatedText);
      }
    }, 500);
  };

  const stopListening = () => {
    setIsListening(false);
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
    }
    setTranscript(interimTranscript || 'Hello thank you please good morning');
    setInterimTranscript('');
  };

  useEffect(() => {
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, []);

  return { isListening, transcript, interimTranscript, startListening, stopListening };
};

export default function SpeakingSection({ onBack }: SpeakingSectionProps) {
  const [selectedLesson, setSelectedLesson] = useState<SpeakingLesson | null>(null);
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const [hasRecorded, setHasRecorded] = useState(false);
  const [score, setScore] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [recordingComplete, setRecordingComplete] = useState(false);
  const { isListening, transcript, interimTranscript, startListening, stopListening } = useSpeechRecognition();
  const { addXP, completeLesson } = useUserProgress();

  const handleLessonSelect = (lesson: SpeakingLesson) => {
    setSelectedLesson(lesson);
    setCurrentExerciseIndex(0);
    setScore(0);
    setCompleted(false);
    setHasRecorded(false);
    setRecordingComplete(false);
  };

  const handleStartRecording = () => {
    startListening();
    setHasRecorded(true);
  };

  const handleStopRecording = () => {
    stopListening();
    setRecordingComplete(true);
    // Simulate scoring
    const simulatedScore = Math.floor(Math.random() * 20) + 80; // 80-100
    setScore(prev => prev + simulatedScore);
    toast.success(`Recording complete! Score: ${simulatedScore}%`);
  };

  const handleNextExercise = () => {
    if (!selectedLesson) return;

    if (currentExerciseIndex < selectedLesson.exercises.length - 1) {
      setCurrentExerciseIndex(currentExerciseIndex + 1);
      setHasRecorded(false);
      setRecordingComplete(false);
      setShowHint(false);
    } else {
      setCompleted(true);
      const xpEarned = Math.round((score / selectedLesson.exercises.length) / 2);
      addXP(xpEarned);
      completeLesson();
      toast.success(`Lesson completed! You earned ${xpEarned} XP!`);
    }
  };

  const renderExercise = (exercise: SpeakingExercise) => {
    switch (exercise.type) {
      case 'repeat':
      case 'read':
        return (
          <div className="space-y-6">
            <div className="bg-slate-50 rounded-2xl p-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-semibold text-slate-700">Text to read:</h4>
                <button className="p-2 rounded-full bg-purple-100 text-purple-600 hover:bg-purple-200 transition-colors">
                  <Volume2 className="w-5 h-5" />
                </button>
              </div>
              <p className="text-lg text-slate-800 leading-relaxed">{exercise.content}</p>
            </div>

            {/* Recording Area */}
            <div className="flex flex-col items-center">
              <motion.button
                onClick={isListening ? handleStopRecording : handleStartRecording}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`w-24 h-24 rounded-full flex items-center justify-center shadow-lg transition-all ${
                  isListening
                    ? 'bg-red-500 shadow-red-500/30 mic-recording'
                    : 'bg-gradient-to-br from-purple-600 to-blue-600 shadow-purple-500/30'
                }`}
              >
                {isListening ? <MicOff className="w-10 h-10 text-white" /> : <Mic className="w-10 h-10 text-white" />}
              </motion.button>
              <p className="mt-4 text-slate-600 font-medium">
                {isListening ? 'Listening... Tap to stop' : hasRecorded ? 'Tap to record again' : 'Tap to start speaking'}
              </p>

              {/* Waveform visualization when recording */}
              {isListening && (
                <div className="flex items-center justify-center gap-1 h-16 mt-4">
                  {Array.from({ length: 20 }).map((_, i) => (
                    <motion.div
                      key={i}
                      className="w-2 bg-purple-500 rounded-full"
                      animate={{
                        height: [10, Math.random() * 40 + 10, 10],
                      }}
                      transition={{
                        duration: 0.3,
                        repeat: Infinity,
                        delay: i * 0.05,
                      }}
                    />
                  ))}
                </div>
              )}

              {/* Transcript display */}
              <AnimatePresence>
                {(interimTranscript || transcript) && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="mt-6 p-4 bg-white rounded-xl border border-slate-200 max-w-md w-full"
                  >
                    <p className="text-sm text-slate-500 mb-1">What we heard:</p>
                    <p className="text-slate-800">{interimTranscript || transcript}</p>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>
        );

      case 'dialogue':
        return (
          <div className="space-y-6">
            <div className="bg-slate-50 rounded-2xl p-6">
              <h4 className="font-semibold text-slate-700 mb-4">Dialogue:</h4>
              <div className="space-y-3">
                {exercise.content.split('\n').map((line, idx) => {
                  const isCustomer = line.includes('Customer:') || line.includes('Friend B:');
                  const isYou = isCustomer;
                  return (
                    <div
                      key={idx}
                      className={`p-3 rounded-xl ${
                        isYou ? 'bg-purple-100 ml-8' : 'bg-white mr-8 border border-slate-200'
                      }`}
                    >
                      <p className={`text-sm ${isYou ? 'text-purple-800' : 'text-slate-700'}`}>
                        {line}
                      </p>
                      {isYou && (
                        <span className="text-xs text-purple-600 font-medium">← Your line</span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Recording Area */}
            <div className="flex flex-col items-center">
              <motion.button
                onClick={isListening ? handleStopRecording : handleStartRecording}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`w-24 h-24 rounded-full flex items-center justify-center shadow-lg transition-all ${
                  isListening
                    ? 'bg-red-500 shadow-red-500/30 mic-recording'
                    : 'bg-gradient-to-br from-purple-600 to-blue-600 shadow-purple-500/30'
                }`}
              >
                {isListening ? <MicOff className="w-10 h-10 text-white" /> : <Mic className="w-10 h-10 text-white" />}
              </motion.button>
              <p className="mt-4 text-slate-600 font-medium">
                {isListening ? 'Listening...' : 'Practice your lines'}
              </p>
            </div>
          </div>
        );

      case 'describe':
        return (
          <div className="space-y-6">
            <div className="bg-slate-50 rounded-2xl p-6">
              <h4 className="font-semibold text-slate-700 mb-4">Describe this scene:</h4>
              <div className="bg-gradient-to-br from-blue-100 to-purple-100 rounded-xl p-6">
                <p className="text-slate-700 italic">{exercise.content}</p>
              </div>
              <p className="text-sm text-slate-500 mt-4">
                Speak for at least 30 seconds describing what you see.
              </p>
            </div>

            {/* Recording Area */}
            <div className="flex flex-col items-center">
              <motion.button
                onClick={isListening ? handleStopRecording : handleStartRecording}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className={`w-24 h-24 rounded-full flex items-center justify-center shadow-lg transition-all ${
                  isListening
                    ? 'bg-red-500 shadow-red-500/30 mic-recording'
                    : 'bg-gradient-to-br from-purple-600 to-blue-600 shadow-purple-500/30'
                }`}
              >
                {isListening ? <MicOff className="w-10 h-10 text-white" /> : <Mic className="w-10 h-10 text-white" />}
              </motion.button>
              <p className="mt-4 text-slate-600 font-medium">
                {isListening ? 'Recording... Tap when done' : 'Tap to describe'}
              </p>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  if (selectedLesson) {
    const currentExercise = selectedLesson.exercises[currentExerciseIndex];

    return (
      <div className="min-h-screen bg-slate-50 pt-20 pb-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">
          {/* Header */}
          <div className="flex items-center gap-4 mb-6">
            <button
              onClick={() => setSelectedLesson(null)}
              className="p-2 rounded-full hover:bg-slate-200 transition-colors"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-slate-800">{selectedLesson.title}</h1>
              <div className="flex items-center gap-3 text-sm text-slate-500">
                <span className="px-2 py-1 bg-pink-100 text-pink-700 rounded-full">{selectedLesson.level}</span>
              </div>
            </div>
          </div>

          {!completed ? (
            <>
              {/* Progress */}
              <div className="mb-6">
                <Progress 
                  value={((currentExerciseIndex + 1) / selectedLesson.exercises.length) * 100} 
                  className="h-2" 
                />
                <p className="text-sm text-slate-500 mt-2">
                  Exercise {currentExerciseIndex + 1} of {selectedLesson.exercises.length}
                </p>
              </div>

              {/* Exercise Card */}
              <motion.div
                key={currentExerciseIndex}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100"
              >
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-xl font-bold text-slate-800">{currentExercise.title}</h3>
                    <p className="text-slate-600">{currentExercise.instruction}</p>
                  </div>
                  {currentExercise.hint && (
                    <button
                      onClick={() => setShowHint(!showHint)}
                      className="p-2 rounded-full bg-yellow-100 text-yellow-600 hover:bg-yellow-200 transition-colors"
                    >
                      <Lightbulb className="w-5 h-5" />
                    </button>
                  )}
                </div>

                <AnimatePresence>
                  {showHint && currentExercise.hint && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mb-4 p-4 bg-yellow-50 rounded-xl text-sm text-yellow-700"
                    >
                      <Lightbulb className="w-4 h-4 inline mr-1" />
                      {currentExercise.hint}
                    </motion.div>
                  )}
                </AnimatePresence>

                {renderExercise(currentExercise)}

                {/* Next Button */}
                {recordingComplete && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="mt-6 flex justify-end"
                  >
                    <Button
                      onClick={handleNextExercise}
                      className="bg-purple-600 hover:bg-purple-700 text-white"
                    >
                      {currentExerciseIndex < selectedLesson.exercises.length - 1 ? 'Next Exercise' : 'Finish'}
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  </motion.div>
                )}
              </motion.div>
            </>
          ) : (
            /* Completion Screen */
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100 text-center"
            >
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Trophy className="w-10 h-10 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-slate-800 mb-2">Great Job!</h2>
              <p className="text-slate-600 mb-6">
                You've completed all speaking exercises!
              </p>
              <div className="flex justify-center gap-4">
                <Button
                  onClick={() => setSelectedLesson(null)}
                  variant="outline"
                  className="rounded-full"
                >
                  Back to Lessons
                </Button>
                <Button
                  onClick={() => {
                    setCurrentExerciseIndex(0);
                    setScore(0);
                    setCompleted(false);
                    setHasRecorded(false);
                    setRecordingComplete(false);
                  }}
                  className="bg-purple-600 hover:bg-purple-700 text-white rounded-full"
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  Practice Again
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    );
  }

  // Lesson List
  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={onBack}
            className="p-2 rounded-full hover:bg-slate-200 transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-slate-800">Speaking Practice</h1>
            <p className="text-slate-600">Improve your pronunciation and fluency</p>
          </div>
        </div>

        {/* Tips Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-pink-500 to-rose-500 rounded-2xl p-6 text-white mb-8"
        >
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
              <Mic className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-lg mb-2">Speaking Tips</h3>
              <ul className="space-y-1 text-sm text-white/90">
                <li>• Speak clearly and at a natural pace</li>
                <li>• Don't worry about making mistakes</li>
                <li>• Practice regularly, even just 5 minutes a day</li>
                <li>• Record yourself to hear your progress</li>
              </ul>
            </div>
          </div>
        </motion.div>

        {/* Lessons Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {speakingLessons.map((lesson, index) => (
            <motion.div
              key={lesson.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -4 }}
              onClick={() => handleLessonSelect(lesson)}
              className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 cursor-pointer hover:shadow-md transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-pink-100 rounded-xl flex items-center justify-center">
                  <MessageCircle className="w-6 h-6 text-pink-600" />
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                  lesson.level === 'A1' ? 'bg-green-100 text-green-700' :
                  lesson.level === 'A2' ? 'bg-blue-100 text-blue-700' :
                  'bg-purple-100 text-purple-700'
                }`}>
                  {lesson.level}
                </span>
              </div>

              <h3 className="text-lg font-bold text-slate-800 mb-2">{lesson.title}</h3>
              <p className="text-sm text-slate-600 mb-4">{lesson.description}</p>

              <div className="flex items-center gap-4 text-sm text-slate-500 mb-4">
                <span className="flex items-center gap-1">
                  <Mic className="w-4 h-4" />
                  {lesson.exercises.length} exercises
                </span>
              </div>

              <Button size="sm" className="bg-pink-500 hover:bg-pink-600 text-white rounded-full">
                Start Speaking
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </motion.div>
          ))}
        </div>

        {/* Daily Challenge */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl p-6 text-white"
        >
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2 mb-2">
                <Sparkles className="w-5 h-5" />
                <h3 className="font-bold text-lg">Daily Speaking Challenge</h3>
              </div>
              <p className="text-purple-100">Talk about your favorite hobby for 1 minute</p>
            </div>
            <Button className="bg-white text-purple-600 hover:bg-purple-50 rounded-full">
              <Play className="w-4 h-4 mr-2" />
              Start
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
