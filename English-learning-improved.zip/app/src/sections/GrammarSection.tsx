import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, 
  PenTool, 
  CheckCircle, 
  XCircle, 
  Lightbulb,
  ChevronRight,
  BookOpen,
  Edit3,
  Check
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { useUserProgress } from '@/hooks/useUserProgress';

interface GrammarSectionProps {
  onBack: () => void;
}

interface GrammarExercise {
  id: number;
  type: 'fillblank' | 'multiple' | 'correction' | 'ordering';
  instruction: string;
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  hint?: string;
}

interface GrammarLesson {
  id: number;
  title: string;
  topic: string;
  level: string;
  content: {
    explanation: string;
    rules: string[];
    examples: { correct: string; incorrect?: string; explanation: string }[];
  };
  exercises: GrammarExercise[];
}

const grammarLessons: GrammarLesson[] = [
  {
    id: 1,
    title: 'Present Simple Tense',
    topic: 'Tenses',
    level: 'A1',
    content: {
      explanation: 'The Present Simple tense is used to describe habits, unchanging situations, general truths, and fixed arrangements.',
      rules: [
        'Use the base form of the verb for I, you, we, they',
        'Add -s or -es to the verb for he, she, it',
        'Use "do/does" for questions and negatives',
      ],
      examples: [
        { correct: 'She works every day.', explanation: 'Third person singular adds -s' },
        { correct: 'I like coffee.', incorrect: 'I likes coffee.', explanation: 'First person uses base form' },
        { correct: 'Do they live here?', explanation: 'Questions use "do" + base form' },
      ],
    },
    exercises: [
      {
        id: 1,
        type: 'fillblank',
        instruction: 'Fill in the blank with the correct form of the verb.',
        question: 'She _____ (work) in a hospital.',
        correctAnswer: 'works',
        explanation: 'For third person singular (she), we add -s to the verb.',
        hint: 'Remember: he/she/it + verb + s/es',
      },
      {
        id: 2,
        type: 'multiple',
        instruction: 'Choose the correct sentence.',
        question: 'Which sentence is correct?',
        options: [
          'I goes to school every day.',
          'I go to school every day.',
          'I going to school every day.',
          'I gone to school every day.',
        ],
        correctAnswer: 'I go to school every day.',
        explanation: 'With "I", we use the base form of the verb: "go", not "goes".',
      },
      {
        id: 3,
        type: 'correction',
        instruction: 'Find and correct the mistake in this sentence.',
        question: "He don't like vegetables.",
        correctAnswer: "He doesn't like vegetables.",
        explanation: "For third person singular negatives, use 'doesn't' (does not), not 'don't'.",
      },
      {
        id: 4,
        type: 'fillblank',
        instruction: 'Fill in the blank with the correct form.',
        question: '_____ you _____ (speak) English?',
        correctAnswer: 'Do you speak',
        explanation: 'Questions in present simple use "do/does" + subject + base verb.',
      },
    ],
  },
  {
    id: 2,
    title: 'Articles: A, An, The',
    topic: 'Articles',
    level: 'A1',
    content: {
      explanation: 'Articles are small words that come before nouns. They help us understand if we are talking about something specific or general.',
      rules: [
        'Use "a" before words starting with a consonant sound',
        'Use "an" before words starting with a vowel sound (a, e, i, o, u)',
        'Use "the" when talking about something specific or already mentioned',
      ],
      examples: [
        { correct: 'I have a book.', explanation: '"A" for general singular countable noun' },
        { correct: 'She is an artist.', explanation: '"An" before vowel sound' },
        { correct: 'The book on the table is mine.', explanation: '"The" for specific noun' },
      ],
    },
    exercises: [
      {
        id: 1,
        type: 'fillblank',
        instruction: 'Fill in the blank with a, an, or the.',
        question: 'I saw _____ elephant at _____ zoo.',
        correctAnswer: 'an elephant at the zoo',
        explanation: '"An" before elephant (vowel sound), "the" for specific zoo.',
      },
      {
        id: 2,
        type: 'multiple',
        instruction: 'Choose the correct article.',
        question: 'She is _____ university student.',
        options: ['a', 'an', 'the', 'no article'],
        correctAnswer: 'a',
        explanation: 'Use "a" before "university" because it starts with a consonant sound (y).',
      },
    ],
  },
];

export default function GrammarSection({ onBack }: GrammarSectionProps) {
  const [selectedLesson, setSelectedLesson] = useState<GrammarLesson | null>(null);
  const [currentExerciseIndex, setCurrentExerciseIndex] = useState(0);
  const [userAnswer, setUserAnswer] = useState('');
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [showRules, setShowRules] = useState(true);
  const { addXP, completeLesson } = useUserProgress();

  const handleLessonSelect = (lesson: GrammarLesson) => {
    setSelectedLesson(lesson);
    setCurrentExerciseIndex(0);
    setScore(0);
    setCompleted(false);
    setShowRules(true);
  };

  const handleAnswerSubmit = () => {
    if (!selectedLesson || !userAnswer.trim()) return;

    const currentExercise = selectedLesson.exercises[currentExerciseIndex];
    const isCorrect = userAnswer.toLowerCase().trim() === currentExercise.correctAnswer.toLowerCase().trim();

    setShowResult(true);
    
    if (isCorrect) {
      setScore(score + 1);
      toast.success('Excellent! That\'s correct!');
    } else {
      toast.error('Not quite. Review the explanation!');
    }
  };

  const handleNextExercise = () => {
    if (!selectedLesson) return;

    if (currentExerciseIndex < selectedLesson.exercises.length - 1) {
      setCurrentExerciseIndex(currentExerciseIndex + 1);
      setUserAnswer('');
      setShowResult(false);
      setShowHint(false);
    } else {
      setCompleted(true);
      const xpEarned = Math.round((score / selectedLesson.exercises.length) * 50);
      addXP(xpEarned);
      completeLesson();
      toast.success(`Lesson completed! You earned ${xpEarned} XP!`);
    }
  };

  const renderExercise = (exercise: GrammarExercise) => {
    switch (exercise.type) {
      case 'fillblank':
        return (
          <div className="space-y-4">
            <p className="text-lg text-slate-700">{exercise.question}</p>
            <input
              type="text"
              value={userAnswer}
              onChange={(e) => setUserAnswer(e.target.value)}
              disabled={showResult}
              placeholder="Type your answer here..."
              className="w-full p-4 border-2 border-slate-200 rounded-xl focus:border-purple-500 focus:outline-none transition-colors"
            />
          </div>
        );

      case 'multiple':
        return (
          <div className="space-y-3">
            <p className="text-lg text-slate-700 mb-4">{exercise.question}</p>
            {exercise.options?.map((option) => (
              <button
                key={option}
                onClick={() => setUserAnswer(option)}
                disabled={showResult}
                className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                  userAnswer === option
                    ? showResult
                      ? option === exercise.correctAnswer
                        ? 'border-green-500 bg-green-100'
                        : 'border-red-500 bg-red-100'
                      : 'border-purple-500 bg-purple-100'
                    : 'border-slate-200 hover:border-purple-300'
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        );

      case 'correction':
        return (
          <div className="space-y-4">
            <div className="p-4 bg-slate-100 rounded-xl">
              <p className="text-lg text-slate-700 font-medium">{exercise.question}</p>
            </div>
            <p className="text-sm text-slate-500">Write the correct sentence:</p>
            <input
              type="text"
              value={userAnswer}
              onChange={(e) => setUserAnswer(e.target.value)}
              disabled={showResult}
              placeholder="Type the correct sentence..."
              className="w-full p-4 border-2 border-slate-200 rounded-xl focus:border-purple-500 focus:outline-none transition-colors"
            />
          </div>
        );

      default:
        return null;
    }
  };

  if (selectedLesson) {
    return (
      <div className="min-h-screen bg-slate-50 pt-20 pb-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          {/* Header */}
          <div className="flex items-center gap-4 mb-6">
            <button
              onClick={() => setSelectedLesson(null)}
              className="p-2 rounded-full hover:bg-slate-200 transition-colors"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-slate-800">{selectedLesson.title}</h1>
              <div className="flex items-center gap-3 text-sm text-slate-500">
                <span className="px-2 py-1 bg-blue-100 text-blue-700 rounded-full">{selectedLesson.level}</span>
                <span className="px-2 py-1 bg-purple-100 text-purple-700 rounded-full">{selectedLesson.topic}</span>
              </div>
            </div>
          </div>

          {!completed ? (
            <>
              {/* Progress */}
              <div className="mb-6">
                <Progress 
                  value={((currentExerciseIndex + 1) / selectedLesson.exercises.length) * 100} 
                  className="h-2" 
                />
                <p className="text-sm text-slate-500 mt-2">
                  Exercise {currentExerciseIndex + 1} of {selectedLesson.exercises.length}
                </p>
              </div>

              {/* Rules Section */}
              <AnimatePresence>
                {showRules && (
                  <motion.div
                    initial={{ opacity: 0, height: 0 }}
                    animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }}
                    className="bg-gradient-to-br from-blue-50 to-purple-50 rounded-2xl p-6 border border-blue-100 mb-6"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                        <BookOpen className="w-5 h-5 text-blue-600" />
                        Grammar Rules
                      </h3>
                      <button
                        onClick={() => setShowRules(false)}
                        className="text-slate-400 hover:text-slate-600"
                      >
                        Hide
                      </button>
                    </div>
                    
                    <p className="text-slate-700 mb-4">{selectedLesson.content.explanation}</p>
                    
                    <div className="space-y-2 mb-4">
                      <h4 className="font-semibold text-slate-800">Key Rules:</h4>
                      <ul className="space-y-1">
                        {selectedLesson.content.rules.map((rule, idx) => (
                          <li key={idx} className="flex items-start gap-2 text-sm text-slate-600">
                            <Check className="w-4 h-4 text-green-500 flex-shrink-0 mt-0.5" />
                            {rule}
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="space-y-2">
                      <h4 className="font-semibold text-slate-800">Examples:</h4>
                      <div className="grid gap-2">
                        {selectedLesson.content.examples.map((example, idx) => (
                          <div key={idx} className="bg-white rounded-lg p-3">
                            {example.incorrect && (
                              <p className="text-red-500 text-sm line-through mb-1">{example.incorrect}</p>
                            )}
                            <p className="text-green-600 font-medium text-sm">{example.correct}</p>
                            <p className="text-slate-500 text-xs mt-1">{example.explanation}</p>
                          </div>
                        ))}
                      </div>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Exercise */}
              <motion.div
                key={currentExerciseIndex}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100"
              >
                <div className="flex items-center justify-between mb-4">
                  <p className="text-sm font-medium text-purple-600">
                    {selectedLesson.exercises[currentExerciseIndex].instruction}
                  </p>
                  {selectedLesson.exercises[currentExerciseIndex].hint && (
                    <button
                      onClick={() => setShowHint(!showHint)}
                      className="flex items-center gap-1 text-sm text-yellow-600 hover:text-yellow-700"
                    >
                      <Lightbulb className="w-4 h-4" />
                      Hint
                    </button>
                  )}
                </div>

                <AnimatePresence>
                  {showHint && selectedLesson.exercises[currentExerciseIndex].hint && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mb-4 p-3 bg-yellow-50 rounded-xl text-sm text-yellow-700"
                    >
                      <Lightbulb className="w-4 h-4 inline mr-1" />
                      {selectedLesson.exercises[currentExerciseIndex].hint}
                    </motion.div>
                  )}
                </AnimatePresence>

                {renderExercise(selectedLesson.exercises[currentExerciseIndex])}

                {/* Result */}
                <AnimatePresence>
                  {showResult && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-6 p-4 rounded-xl bg-slate-50"
                    >
                      <div className="flex items-start gap-3">
                        {userAnswer.toLowerCase().trim() === selectedLesson.exercises[currentExerciseIndex].correctAnswer.toLowerCase().trim() ? (
                          <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0" />
                        ) : (
                          <XCircle className="w-6 h-6 text-red-500 flex-shrink-0" />
                        )}
                        <div>
                          <p className="font-semibold text-slate-800 mb-1">
                            {userAnswer.toLowerCase().trim() === selectedLesson.exercises[currentExerciseIndex].correctAnswer.toLowerCase().trim()
                              ? 'Correct!'
                              : 'Not quite right'}
                          </p>
                          <p className="text-sm text-slate-600 mb-2">
                            {selectedLesson.exercises[currentExerciseIndex].explanation}
                          </p>
                          <p className="text-sm text-green-600 font-medium">
                            Correct answer: {selectedLesson.exercises[currentExerciseIndex].correctAnswer}
                          </p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Actions */}
                <div className="mt-6 flex justify-end gap-3">
                  {!showResult ? (
                    <Button
                      onClick={handleAnswerSubmit}
                      disabled={!userAnswer.trim()}
                      className="bg-purple-600 hover:bg-purple-700 text-white"
                    >
                      <Edit3 className="w-4 h-4 mr-2" />
                      Check Answer
                    </Button>
                  ) : (
                    <Button
                      onClick={handleNextExercise}
                      className="bg-purple-600 hover:bg-purple-700 text-white"
                    >
                      {currentExerciseIndex < selectedLesson.exercises.length - 1 ? 'Next Exercise' : 'Finish'}
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  )}
                </div>
              </motion.div>
            </>
          ) : (
            /* Completion Screen */
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100 text-center"
            >
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle className="w-10 h-10 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-slate-800 mb-2">Lesson Completed!</h2>
              <p className="text-slate-600 mb-6">
                You got {score} out of {selectedLesson.exercises.length} exercises correct!
              </p>
              <div className="flex justify-center gap-4">
                <Button
                  onClick={() => setSelectedLesson(null)}
                  variant="outline"
                  className="rounded-full"
                >
                  Back to Lessons
                </Button>
                <Button
                  onClick={() => {
                    setCurrentExerciseIndex(0);
                    setScore(0);
                    setCompleted(false);
                    setUserAnswer('');
                    setShowResult(false);
                  }}
                  className="bg-purple-600 hover:bg-purple-700 text-white rounded-full"
                >
                  Retry Lesson
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    );
  }

  // Lesson List
  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={onBack}
            className="p-2 rounded-full hover:bg-slate-200 transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-slate-800">Grammar & Writing</h1>
            <p className="text-slate-600">Master English grammar with interactive lessons</p>
          </div>
        </div>

        {/* Topics */}
        <div className="flex gap-2 mb-6 overflow-x-auto pb-2">
          {['All', 'Tenses', 'Articles', 'Prepositions', 'Conditionals', 'Modal Verbs'].map((topic) => (
            <button
              key={topic}
              className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-colors ${
                topic === 'All'
                  ? 'bg-purple-600 text-white'
                  : 'bg-white text-slate-600 hover:bg-purple-50'
              }`}
            >
              {topic}
            </button>
          ))}
        </div>

        {/* Lessons Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {grammarLessons.map((lesson, index) => (
            <motion.div
              key={lesson.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -4 }}
              onClick={() => handleLessonSelect(lesson)}
              className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 cursor-pointer hover:shadow-md transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center">
                  <PenTool className="w-6 h-6 text-blue-600" />
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                  lesson.level === 'A1' ? 'bg-green-100 text-green-700' :
                  lesson.level === 'A2' ? 'bg-blue-100 text-blue-700' :
                  'bg-purple-100 text-purple-700'
                }`}>
                  {lesson.level}
                </span>
              </div>

              <h3 className="text-lg font-bold text-slate-800 mb-1">{lesson.title}</h3>
              <p className="text-sm text-purple-600 mb-4">{lesson.topic}</p>

              <div className="flex items-center gap-4 text-sm text-slate-500 mb-4">
                <span>{lesson.content.rules.length} rules</span>
                <span>{lesson.exercises.length} exercises</span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex -space-x-2">
                  {lesson.content.examples.slice(0, 3).map((_, i) => (
                    <div key={i} className="w-8 h-8 rounded-full bg-gradient-to-br from-blue-400 to-purple-400 border-2 border-white" />
                  ))}
                </div>
                <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white rounded-full">
                  Start Lesson
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
