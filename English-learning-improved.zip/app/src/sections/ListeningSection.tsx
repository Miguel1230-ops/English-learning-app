import { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, 
  Headphones, 
  Play, 
  Pause, 
  RotateCcw,
  CheckCircle, 
  XCircle,
  Volume2,
  ChevronRight,
  Clock,
  Mic,
  Sparkles
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { useUserProgress } from '@/hooks/useUserProgress';

interface ListeningSectionProps {
  onBack: () => void;
}

interface ListeningQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: string;
  timestamp: number; // When in the audio this question should appear
}

interface ListeningLesson {
  id: number;
  title: string;
  level: string;
  duration: string;
  description: string;
  transcript: string;
  questions: ListeningQuestion[];
}

const listeningLessons: ListeningLesson[] = [
  {
    id: 1,
    title: 'At the Coffee Shop',
    level: 'A1',
    duration: '1:30',
    description: 'Listen to a conversation between a customer and a barista.',
    transcript: `Barista: Good morning! Welcome to Coffee Corner. What can I get for you today?

Customer: Good morning! I'd like a medium latte, please.

Barista: Sure thing! Would you like any flavor in that? We have vanilla, caramel, and hazelnut.

Customer: Hmm, I'll try caramel. That sounds good.

Barista: Excellent choice! Will that be for here or to go?

Customer: To go, please. I'm running a bit late for work.

Barista: No problem! That'll be $4.50. Would you like anything else? Maybe a pastry?

Customer: Oh, why not? I'll have a blueberry muffin too.

Barista: Great! So that's a medium caramel latte to go and one blueberry muffin. Your total is $7.25.

Customer: Here you go. Keep the change.

Barista: Thank you so much! Your order will be ready in just a minute. Have a wonderful day!

Customer: Thanks! You too!`,
    questions: [
      {
        id: 1,
        question: 'What size coffee did the customer order?',
        options: ['Small', 'Medium', 'Large', 'Extra Large'],
        correctAnswer: 'Medium',
        timestamp: 15,
      },
      {
        id: 2,
        question: 'What flavor did the customer choose?',
        options: ['Vanilla', 'Caramel', 'Hazelnut', 'No flavor'],
        correctAnswer: 'Caramel',
        timestamp: 30,
      },
      {
        id: 3,
        question: 'Where did the customer want to drink the coffee?',
        options: ['In the shop', 'To go', 'At home', 'At work'],
        correctAnswer: 'To go',
        timestamp: 45,
      },
      {
        id: 4,
        question: 'What else did the customer buy?',
        options: ['A croissant', 'A cookie', 'A blueberry muffin', 'Nothing else'],
        correctAnswer: 'A blueberry muffin',
        timestamp: 60,
      },
    ],
  },
  {
    id: 2,
    title: 'Making Weekend Plans',
    level: 'A2',
    duration: '2:00',
    description: 'Two friends discuss their plans for the weekend.',
    transcript: `Sarah: Hey Mike! Do you have any plans for the weekend?

Mike: Hi Sarah! Not really, I was just thinking about relaxing at home. Why? Do you have something in mind?

Sarah: Well, I heard there's a new art exhibition downtown. I was thinking about checking it out on Saturday. Would you like to come?

Mike: An art exhibition? That sounds interesting! What kind of art is it?

Sarah: It's modern art from local artists. I saw some photos online, and the pieces look really colorful and creative.

Mike: That does sound cool. What time were you thinking?

Sarah: Maybe around 2 PM? We could grab lunch first at that new Italian place nearby.

Mike: Oh, I've been wanting to try that restaurant! Their pasta looks amazing in the photos.

Sarah: Exactly! And after the exhibition, if we have time, we could walk around the park. The weather is supposed to be beautiful this weekend.

Mike: That sounds like a perfect Saturday! Count me in.

Sarah: Great! Should we invite anyone else?

Mike: Maybe we could ask Jessica? She loves art, and I think she's free this weekend.

Sarah: Good idea! I'll text her. This is going to be fun!

Mike: Definitely! I'm looking forward to it.`,
    questions: [
      {
        id: 1,
        question: 'What does Sarah want to do on Saturday?',
        options: ['Go to the movies', 'Visit an art exhibition', 'Have a picnic', 'Go shopping'],
        correctAnswer: 'Visit an art exhibition',
        timestamp: 20,
      },
      {
        id: 2,
        question: 'Where do they plan to have lunch?',
        options: ['At a new Italian restaurant', 'At home', 'At the exhibition', 'At a park'],
        correctAnswer: 'At a new Italian restaurant',
        timestamp: 50,
      },
      {
        id: 3,
        question: 'Who else might they invite?',
        options: ['Tom', 'Jessica', 'Emma', 'No one else'],
        correctAnswer: 'Jessica',
        timestamp: 90,
      },
    ],
  },
];

export default function ListeningSection({ onBack }: ListeningSectionProps) {
  const [selectedLesson, setSelectedLesson] = useState<ListeningLesson | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  const [showTranscript, setShowTranscript] = useState(false);
  const [audioProgress, setAudioProgress] = useState(0);
  const { addXP, completeLesson } = useUserProgress();
  const audioIntervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const handleLessonSelect = (lesson: ListeningLesson) => {
    setSelectedLesson(lesson);
    setCurrentQuestionIndex(0);
    setScore(0);
    setCompleted(false);
    setAudioProgress(0);
    setIsPlaying(false);
  };

  const simulateAudioPlay = () => {
    setIsPlaying(true);
    audioIntervalRef.current = setInterval(() => {
      setAudioProgress(prev => {
        if (prev >= 100) {
          setIsPlaying(false);
          if (audioIntervalRef.current) clearInterval(audioIntervalRef.current);
          return 100;
        }
        return prev + 1;
      });
    }, 100);
  };

  const simulateAudioPause = () => {
    setIsPlaying(false);
    if (audioIntervalRef.current) clearInterval(audioIntervalRef.current);
  };

  const handleAnswerSubmit = () => {
    if (!selectedLesson || !selectedAnswer) return;

    const currentQuestion = selectedLesson.questions[currentQuestionIndex];
    const isCorrect = selectedAnswer === currentQuestion.correctAnswer;

    setShowResult(true);
    
    if (isCorrect) {
      setScore(score + 1);
      toast.success('Correct! Great listening!');
    } else {
      toast.error('Not quite. Listen again!');
    }
  };

  const handleNextQuestion = () => {
    if (!selectedLesson) return;

    if (currentQuestionIndex < selectedLesson.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(null);
      setShowResult(false);
      setAudioProgress(0);
      setIsPlaying(false);
    } else {
      setCompleted(true);
      const xpEarned = Math.round((score / selectedLesson.questions.length) * 50);
      addXP(xpEarned);
      completeLesson();
      toast.success(`Lesson completed! You earned ${xpEarned} XP!`);
    }
  };

  useEffect(() => {
    return () => {
      if (audioIntervalRef.current) clearInterval(audioIntervalRef.current);
    };
  }, []);

  if (selectedLesson) {
    const currentQuestion = selectedLesson.questions[currentQuestionIndex];

    return (
      <div className="min-h-screen bg-slate-50 pt-20 pb-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          {/* Header */}
          <div className="flex items-center gap-4 mb-6">
            <button
              onClick={() => setSelectedLesson(null)}
              className="p-2 rounded-full hover:bg-slate-200 transition-colors"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-slate-800">{selectedLesson.title}</h1>
              <div className="flex items-center gap-3 text-sm text-slate-500">
                <span className="px-2 py-1 bg-yellow-100 text-yellow-700 rounded-full">{selectedLesson.level}</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {selectedLesson.duration}
                </span>
              </div>
            </div>
          </div>

          {!completed ? (
            <>
              {/* Progress */}
              <div className="mb-6">
                <Progress 
                  value={((currentQuestionIndex + 1) / selectedLesson.questions.length) * 100} 
                  className="h-2" 
                />
                <p className="text-sm text-slate-500 mt-2">
                  Question {currentQuestionIndex + 1} of {selectedLesson.questions.length}
                </p>
              </div>

              {/* Audio Player */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 mb-6"
              >
                <div className="flex items-center gap-4 mb-4">
                  <button
                    onClick={isPlaying ? simulateAudioPause : simulateAudioPlay}
                    className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${
                      isPlaying 
                        ? 'bg-red-100 text-red-600 hover:bg-red-200' 
                        : 'bg-purple-600 text-white hover:bg-purple-700'
                    }`}
                  >
                    {isPlaying ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6 ml-1" />}
                  </button>
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-medium text-slate-700">Listen to the conversation</span>
                      <span className="text-sm text-slate-500">{Math.floor(audioProgress * 1.5 / 100)}:{String(Math.floor((audioProgress * 1.5 % 100) * 0.6)).padStart(2, '0')}</span>
                    </div>
                    <Progress value={audioProgress} className="h-2" />
                  </div>
                  <button
                    onClick={() => setAudioProgress(0)}
                    className="p-2 rounded-full hover:bg-slate-100 transition-colors"
                  >
                    <RotateCcw className="w-5 h-5 text-slate-500" />
                  </button>
                </div>

                {/* Visual Audio Wave */}
                <div className="flex items-center justify-center gap-1 h-12">
                  {Array.from({ length: 30 }).map((_, i) => (
                    <motion.div
                      key={i}
                      className="w-1 bg-purple-500 rounded-full"
                      animate={{
                        height: isPlaying ? [20, Math.random() * 40 + 10, 20] : 4,
                      }}
                      transition={{
                        duration: 0.3,
                        repeat: isPlaying ? Infinity : 0,
                        delay: i * 0.02,
                      }}
                    />
                  ))}
                </div>

                {/* Transcript Toggle */}
                <button
                  onClick={() => setShowTranscript(!showTranscript)}
                  className="mt-4 text-sm text-purple-600 font-medium hover:text-purple-700 flex items-center gap-1"
                >
                  <Sparkles className="w-4 h-4" />
                  {showTranscript ? 'Hide Transcript' : 'Show Transcript'}
                </button>

                <AnimatePresence>
                  {showTranscript && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-4 p-4 bg-slate-50 rounded-xl max-h-60 overflow-y-auto"
                    >
                      <p className="text-sm text-slate-700 whitespace-pre-line">{selectedLesson.transcript}</p>
                    </motion.div>
                  )}
                </AnimatePresence>
              </motion.div>

              {/* Question */}
              <motion.div
                key={currentQuestionIndex}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100"
              >
                <div className="flex items-center gap-2 mb-4">
                  <Headphones className="w-5 h-5 text-purple-600" />
                  <h3 className="text-lg font-semibold text-slate-800">{currentQuestion.question}</h3>
                </div>

                <div className="space-y-3">
                  {currentQuestion.options.map((option) => (
                    <button
                      key={option}
                      onClick={() => setSelectedAnswer(option)}
                      disabled={showResult}
                      className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                        selectedAnswer === option
                          ? showResult
                            ? option === currentQuestion.correctAnswer
                              ? 'border-green-500 bg-green-100'
                              : 'border-red-500 bg-red-100'
                            : 'border-purple-500 bg-purple-100'
                          : 'border-slate-200 hover:border-purple-300'
                      }`}
                    >
                      {option}
                    </button>
                  ))}
                </div>

                {/* Result */}
                <AnimatePresence>
                  {showResult && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-6 p-4 rounded-xl bg-slate-50"
                    >
                      <div className="flex items-start gap-3">
                        {selectedAnswer === currentQuestion.correctAnswer ? (
                          <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0" />
                        ) : (
                          <XCircle className="w-6 h-6 text-red-500 flex-shrink-0" />
                        )}
                        <div>
                          <p className="font-semibold text-slate-800 mb-1">
                            {selectedAnswer === currentQuestion.correctAnswer ? 'Correct!' : 'Not quite right'}
                          </p>
                          <p className="text-sm text-slate-600">
                            The correct answer is: <span className="font-semibold text-green-600">{currentQuestion.correctAnswer}</span>
                          </p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Actions */}
                <div className="mt-6 flex justify-end">
                  {!showResult ? (
                    <Button
                      onClick={handleAnswerSubmit}
                      disabled={!selectedAnswer}
                      className="bg-purple-600 hover:bg-purple-700 text-white"
                    >
                      Check Answer
                    </Button>
                  ) : (
                    <Button
                      onClick={handleNextQuestion}
                      className="bg-purple-600 hover:bg-purple-700 text-white"
                    >
                      {currentQuestionIndex < selectedLesson.questions.length - 1 ? 'Next Question' : 'Finish'}
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  )}
                </div>
              </motion.div>
            </>
          ) : (
            /* Completion Screen */
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100 text-center"
            >
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Headphones className="w-10 h-10 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-slate-800 mb-2">Lesson Completed!</h2>
              <p className="text-slate-600 mb-6">
                You got {score} out of {selectedLesson.questions.length} questions correct!
              </p>
              <div className="flex justify-center gap-4">
                <Button
                  onClick={() => setSelectedLesson(null)}
                  variant="outline"
                  className="rounded-full"
                >
                  Back to Lessons
                </Button>
                <Button
                  onClick={() => {
                    setCurrentQuestionIndex(0);
                    setScore(0);
                    setCompleted(false);
                    setSelectedAnswer(null);
                    setShowResult(false);
                    setAudioProgress(0);
                  }}
                  className="bg-purple-600 hover:bg-purple-700 text-white rounded-full"
                >
                  Retry Lesson
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    );
  }

  // Lesson List
  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={onBack}
            className="p-2 rounded-full hover:bg-slate-200 transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-slate-800">Listening Practice</h1>
            <p className="text-slate-600">Improve your listening skills with native audio</p>
          </div>
        </div>

        {/* Tips Card */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-2xl p-6 text-white mb-8"
        >
          <div className="flex items-start gap-4">
            <div className="w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center flex-shrink-0">
              <Volume2 className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-bold text-lg mb-2">Listening Tips</h3>
              <ul className="space-y-1 text-sm text-white/90">
                <li>• Listen for key words and main ideas</li>
                <li>• Don't worry about understanding every word</li>
                <li>• Take notes while listening</li>
                <li>• Listen multiple times if needed</li>
              </ul>
            </div>
          </div>
        </motion.div>

        {/* Lessons Grid */}
        <div className="grid md:grid-cols-2 gap-6">
          {listeningLessons.map((lesson, index) => (
            <motion.div
              key={lesson.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -4 }}
              onClick={() => handleLessonSelect(lesson)}
              className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 cursor-pointer hover:shadow-md transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-yellow-100 rounded-xl flex items-center justify-center">
                  <Headphones className="w-6 h-6 text-yellow-600" />
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                  lesson.level === 'A1' ? 'bg-green-100 text-green-700' :
                  lesson.level === 'A2' ? 'bg-blue-100 text-blue-700' :
                  'bg-purple-100 text-purple-700'
                }`}>
                  {lesson.level}
                </span>
              </div>

              <h3 className="text-lg font-bold text-slate-800 mb-2">{lesson.title}</h3>
              <p className="text-sm text-slate-600 mb-4">{lesson.description}</p>

              <div className="flex items-center gap-4 text-sm text-slate-500 mb-4">
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {lesson.duration}
                </span>
                <span className="flex items-center gap-1">
                  <Mic className="w-4 h-4" />
                  {lesson.questions.length} questions
                </span>
              </div>

              <Button size="sm" className="bg-yellow-500 hover:bg-yellow-600 text-white rounded-full">
                Start Listening
                <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
