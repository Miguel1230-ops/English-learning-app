import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, 
  BookOpen, 
  CheckCircle, 
  XCircle, 
  Lightbulb,
  ChevronRight,
  Star,
  Clock,
  Volume2
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { useUserProgress } from '@/hooks/useUserProgress';

interface ReadingSectionProps {
  onBack: () => void;
}

interface Question {
  id: number;
  type: 'truefalse' | 'multiple' | 'classification';
  question: string;
  options?: string[];
  correctAnswer: string | string[];
  explanation: string;
}

interface ReadingLesson {
  id: number;
  title: string;
  level: string;
  duration: string;
  content: string;
  questions: Question[];
  vocabulary: { word: string; meaning: string; example: string }[];
}

const lessons: ReadingLesson[] = [
  {
    id: 1,
    title: 'A Day at the Park',
    level: 'A1',
    duration: '5 min',
    content: `Sarah loves going to the park on sunny days. Last Saturday, she woke up early and packed a small bag with water, an apple, and her favorite book. She walked to the nearby park, which took about fifteen minutes.

When she arrived, the park was already full of people. Children were playing on the swings and slides. Some people were jogging on the paths, while others were sitting on benches reading newspapers or chatting with friends.

Sarah found a quiet spot under a big oak tree. She sat on the grass and opened her book. The birds were singing, and a gentle breeze made the leaves dance above her. After reading for an hour, she ate her apple and drank some water.

In the afternoon, Sarah saw her neighbor, Mr. Johnson, walking his dog. They talked for a few minutes about the beautiful weather. Then Sarah decided to go home. She felt happy and relaxed after spending the day at the park.`,
    questions: [
      {
        id: 1,
        type: 'truefalse',
        question: 'Sarah went to the park on Sunday.',
        correctAnswer: 'False',
        explanation: 'The text says Sarah went to the park on Saturday, not Sunday.',
      },
      {
        id: 2,
        type: 'truefalse',
        question: 'Sarah packed water, an apple, and a book.',
        correctAnswer: 'True',
        explanation: 'Correct! The text mentions she packed "water, an apple, and her favorite book."',
      },
      {
        id: 3,
        type: 'multiple',
        question: 'What did Sarah do under the oak tree?',
        options: ['She played on the swings', 'She read her book', 'She jogged on the path', 'She walked a dog'],
        correctAnswer: 'She read her book',
        explanation: 'The text says: "She sat on the grass and opened her book."',
      },
      {
        id: 4,
        type: 'classification',
        question: 'Classify these words: Which are activities people did at the park?',
        correctAnswer: ['playing', 'jogging', 'reading', 'chatting'],
        explanation: 'All these activities are mentioned in the text: children playing, people jogging, reading newspapers, and chatting with friends.',
      },
    ],
    vocabulary: [
      { word: 'gentle', meaning: 'soft and mild', example: 'A gentle breeze made the leaves dance.' },
      { word: 'nearby', meaning: 'close in distance', example: 'She walked to the nearby park.' },
      { word: 'relaxed', meaning: 'calm and free from stress', example: 'She felt happy and relaxed.' },
    ],
  },
  {
    id: 2,
    title: 'My Favorite Restaurant',
    level: 'A2',
    duration: '7 min',
    content: `Maria's favorite restaurant is a small Italian place called "Bella Vista" located in the heart of the city. She discovered it three years ago when she was looking for a quiet place to celebrate her birthday with friends.

The restaurant has a cozy atmosphere with warm lighting and soft music. The walls are decorated with beautiful paintings of Italian countryside scenes. There are about twenty tables, and each one has a small vase with fresh flowers.

The menu offers a variety of delicious dishes. Maria's favorite is the homemade pasta with tomato sauce and fresh basil. The chef, Antonio, makes the pasta by hand every morning. The pizzas are also amazing, baked in a traditional wood-fired oven.

What Maria loves most about Bella Vista is the friendly staff. The waiters remember her name and always recommend new dishes to try. Last month, they even sang "Happy Birthday" when she brought her mother there for her 60th birthday.

The prices are reasonable, and the portions are generous. Maria usually spends about $25 for a complete meal including a main course, dessert, and a drink. She visits the restaurant at least twice a month and always leaves with a smile.`,
    questions: [
      {
        id: 1,
        type: 'truefalse',
        question: 'Bella Vista is a large restaurant with fifty tables.',
        correctAnswer: 'False',
        explanation: 'The text says there are about twenty tables, not fifty.',
      },
      {
        id: 2,
        type: 'multiple',
        question: 'What is Maria\'s favorite dish?',
        options: ['Pizza from wood-fired oven', 'Homemade pasta with tomato sauce', 'Fresh salad with flowers', 'Birthday cake'],
        correctAnswer: 'Homemade pasta with tomato sauce',
        explanation: 'The text states: "Maria\'s favorite is the homemade pasta with tomato sauce and fresh basil."',
      },
      {
        id: 3,
        type: 'multiple',
        question: 'How often does Maria visit the restaurant?',
        options: ['Once a week', 'Twice a month', 'Once a month', 'Every day'],
        correctAnswer: 'Twice a month',
        explanation: 'The text says: "She visits the restaurant at least twice a month."',
      },
    ],
    vocabulary: [
      { word: 'cozy', meaning: 'comfortable and warm', example: 'The restaurant has a cozy atmosphere.' },
      { word: 'generous', meaning: 'large in amount', example: 'The portions are generous.' },
      { word: 'reasonable', meaning: 'fair and not expensive', example: 'The prices are reasonable.' },
    ],
  },
];

export default function ReadingSection({ onBack }: ReadingSectionProps) {
  const [selectedLesson, setSelectedLesson] = useState<ReadingLesson | null>(null);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [score, setScore] = useState(0);
  const [completed, setCompleted] = useState(false);
  const [showVocabulary, setShowVocabulary] = useState(false);
  const { addXP, completeLesson } = useUserProgress();

  const handleLessonSelect = (lesson: ReadingLesson) => {
    setSelectedLesson(lesson);
    setCurrentQuestionIndex(0);
    setScore(0);
    setCompleted(false);
    setShowVocabulary(false);
  };

  const handleAnswerSubmit = () => {
    if (!selectedLesson || !selectedAnswer) return;

    const currentQuestion = selectedLesson.questions[currentQuestionIndex];
    const isCorrect = selectedAnswer === currentQuestion.correctAnswer ||
      (Array.isArray(currentQuestion.correctAnswer) && currentQuestion.correctAnswer.includes(selectedAnswer));

    setShowResult(true);
    
    if (isCorrect) {
      setScore(score + 1);
      toast.success('Correct! Well done!');
    } else {
      toast.error('Not quite right. Check the explanation!');
    }
  };

  const handleNextQuestion = () => {
    if (!selectedLesson) return;

    if (currentQuestionIndex < selectedLesson.questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      setCompleted(true);
      const xpEarned = Math.round((score / selectedLesson.questions.length) * 50);
      addXP(xpEarned);
      completeLesson();
      toast.success(`Lesson completed! You earned ${xpEarned} XP!`);
    }
  };

  const renderQuestion = (question: Question) => {
    switch (question.type) {
      case 'truefalse':
        return (
          <div className="flex gap-4">
            {['True', 'False'].map((option) => (
              <button
                key={option}
                onClick={() => setSelectedAnswer(option)}
                disabled={showResult}
                className={`flex-1 p-4 rounded-xl border-2 font-semibold transition-all ${
                  selectedAnswer === option
                    ? showResult
                      ? option === question.correctAnswer
                        ? 'border-green-500 bg-green-100'
                        : 'border-red-500 bg-red-100'
                      : 'border-purple-500 bg-purple-100'
                    : 'border-slate-200 hover:border-purple-300'
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        );

      case 'multiple':
        return (
          <div className="space-y-3">
            {question.options?.map((option) => (
              <button
                key={option}
                onClick={() => setSelectedAnswer(option)}
                disabled={showResult}
                className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
                  selectedAnswer === option
                    ? showResult
                      ? option === question.correctAnswer
                        ? 'border-green-500 bg-green-100'
                        : 'border-red-500 bg-red-100'
                      : 'border-purple-500 bg-purple-100'
                    : 'border-slate-200 hover:border-purple-300'
                }`}
              >
                {option}
              </button>
            ))}
          </div>
        );

      case 'classification':
        return (
          <div className="grid grid-cols-2 gap-3">
            {['playing', 'jogging', 'reading', 'chatting', 'sleeping', 'cooking'].map((word) => (
              <button
                key={word}
                onClick={() => setSelectedAnswer(word)}
                disabled={showResult}
                className={`p-3 rounded-xl border-2 capitalize transition-all ${
                  selectedAnswer === word
                    ? showResult
                      ? (question.correctAnswer as string[]).includes(word)
                        ? 'border-green-500 bg-green-100'
                        : 'border-red-500 bg-red-100'
                      : 'border-purple-500 bg-purple-100'
                    : 'border-slate-200 hover:border-purple-300'
                }`}
              >
                {word}
              </button>
            ))}
          </div>
        );

      default:
        return null;
    }
  };

  if (selectedLesson) {
    return (
      <div className="min-h-screen bg-slate-50 pt-20 pb-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
          {/* Header */}
          <div className="flex items-center gap-4 mb-6">
            <button
              onClick={() => setSelectedLesson(null)}
              className="p-2 rounded-full hover:bg-slate-200 transition-colors"
            >
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-slate-800">{selectedLesson.title}</h1>
              <div className="flex items-center gap-3 text-sm text-slate-500">
                <span className="px-2 py-1 bg-green-100 text-green-700 rounded-full">{selectedLesson.level}</span>
                <span className="flex items-center gap-1">
                  <Clock className="w-4 h-4" />
                  {selectedLesson.duration}
                </span>
              </div>
            </div>
          </div>

          {!completed ? (
            <>
              {/* Progress */}
              <div className="mb-6">
                <Progress 
                  value={((currentQuestionIndex + 1) / selectedLesson.questions.length) * 100} 
                  className="h-2" 
                />
                <p className="text-sm text-slate-500 mt-2">
                  Question {currentQuestionIndex + 1} of {selectedLesson.questions.length}
                </p>
              </div>

              {/* Reading Content (shown before questions) */}
              {currentQuestionIndex === 0 && !showVocabulary && (
                <motion.div
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 mb-6"
                >
                  <div className="flex items-center justify-between mb-4">
                    <h2 className="text-lg font-semibold text-slate-800">Reading Passage</h2>
                    <button
                      onClick={() => setShowVocabulary(true)}
                      className="flex items-center gap-2 text-purple-600 text-sm font-medium hover:text-purple-700"
                    >
                      <BookOpen className="w-4 h-4" />
                      View Vocabulary
                    </button>
                  </div>
                  <div className="prose prose-slate max-w-none">
                    {selectedLesson.content.split('\n\n').map((paragraph, idx) => (
                      <p key={idx} className="text-slate-700 leading-relaxed mb-4">
                        {paragraph}
                      </p>
                    ))}
                  </div>
                </motion.div>
              )}

              {/* Vocabulary Modal */}
              <AnimatePresence>
                {showVocabulary && (
                  <motion.div
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="bg-gradient-to-br from-purple-50 to-blue-50 rounded-2xl p-6 border border-purple-100 mb-6"
                  >
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="text-lg font-semibold text-slate-800 flex items-center gap-2">
                        <Lightbulb className="w-5 h-5 text-yellow-500" />
                        Key Vocabulary
                      </h3>
                      <button
                        onClick={() => setShowVocabulary(false)}
                        className="text-slate-400 hover:text-slate-600"
                      >
                        Hide
                      </button>
                    </div>
                    <div className="space-y-4">
                      {selectedLesson.vocabulary.map((item, idx) => (
                        <div key={idx} className="bg-white rounded-xl p-4">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="font-bold text-purple-700">{item.word}</span>
                            <button className="text-slate-400 hover:text-purple-600">
                              <Volume2 className="w-4 h-4" />
                            </button>
                          </div>
                          <p className="text-sm text-slate-600 mb-1">{item.meaning}</p>
                          <p className="text-sm text-slate-500 italic">"{item.example}"</p>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Question */}
              <motion.div
                key={currentQuestionIndex}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100"
              >
                <h3 className="text-lg font-semibold text-slate-800 mb-4">
                  {selectedLesson.questions[currentQuestionIndex].question}
                </h3>

                {renderQuestion(selectedLesson.questions[currentQuestionIndex])}

                {/* Result */}
                <AnimatePresence>
                  {showResult && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      className="mt-6 p-4 rounded-xl bg-slate-50"
                    >
                      <div className="flex items-start gap-3">
                        {selectedAnswer === selectedLesson.questions[currentQuestionIndex].correctAnswer ||
                        (Array.isArray(selectedLesson.questions[currentQuestionIndex].correctAnswer) &&
                          selectedLesson.questions[currentQuestionIndex].correctAnswer.includes(selectedAnswer || '')) ? (
                          <CheckCircle className="w-6 h-6 text-green-500 flex-shrink-0" />
                        ) : (
                          <XCircle className="w-6 h-6 text-red-500 flex-shrink-0" />
                        )}
                        <div>
                          <p className="font-semibold text-slate-800 mb-1">
                            {selectedAnswer === selectedLesson.questions[currentQuestionIndex].correctAnswer ||
                            (Array.isArray(selectedLesson.questions[currentQuestionIndex].correctAnswer) &&
                              selectedLesson.questions[currentQuestionIndex].correctAnswer.includes(selectedAnswer || ''))
                              ? 'Correct!'
                              : 'Not quite right'}
                          </p>
                          <p className="text-sm text-slate-600">
                            {selectedLesson.questions[currentQuestionIndex].explanation}
                          </p>
                        </div>
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>

                {/* Actions */}
                <div className="mt-6 flex justify-end">
                  {!showResult ? (
                    <Button
                      onClick={handleAnswerSubmit}
                      disabled={!selectedAnswer}
                      className="bg-purple-600 hover:bg-purple-700 text-white"
                    >
                      Check Answer
                    </Button>
                  ) : (
                    <Button
                      onClick={handleNextQuestion}
                      className="bg-purple-600 hover:bg-purple-700 text-white"
                    >
                      {currentQuestionIndex < selectedLesson.questions.length - 1 ? 'Next Question' : 'Finish'}
                      <ChevronRight className="w-4 h-4 ml-2" />
                    </Button>
                  )}
                </div>
              </motion.div>
            </>
          ) : (
            /* Completion Screen */
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100 text-center"
            >
              <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <Star className="w-10 h-10 text-green-600" />
              </div>
              <h2 className="text-2xl font-bold text-slate-800 mb-2">Lesson Completed!</h2>
              <p className="text-slate-600 mb-6">
                You got {score} out of {selectedLesson.questions.length} questions correct!
              </p>
              <div className="flex justify-center gap-4">
                <Button
                  onClick={() => setSelectedLesson(null)}
                  variant="outline"
                  className="rounded-full"
                >
                  Back to Lessons
                </Button>
                <Button
                  onClick={() => {
                    setCurrentQuestionIndex(0);
                    setScore(0);
                    setCompleted(false);
                    setSelectedAnswer(null);
                    setShowResult(false);
                  }}
                  className="bg-purple-600 hover:bg-purple-700 text-white rounded-full"
                >
                  Retry Lesson
                </Button>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    );
  }

  // Lesson List
  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button
            onClick={onBack}
            className="p-2 rounded-full hover:bg-slate-200 transition-colors"
          >
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-slate-800">Reading Comprehension</h1>
            <p className="text-slate-600">Improve your reading skills with engaging stories</p>
          </div>
        </div>

        {/* Lessons Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {lessons.map((lesson, index) => (
            <motion.div
              key={lesson.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              whileHover={{ y: -4 }}
              onClick={() => handleLessonSelect(lesson)}
              className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 cursor-pointer hover:shadow-md transition-all"
            >
              <div className="flex items-start justify-between mb-4">
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center">
                  <BookOpen className="w-6 h-6 text-purple-600" />
                </div>
                <span className={`px-3 py-1 rounded-full text-xs font-semibold ${
                  lesson.level === 'A1' ? 'bg-green-100 text-green-700' :
                  lesson.level === 'A2' ? 'bg-blue-100 text-blue-700' :
                  'bg-purple-100 text-purple-700'
                }`}>
                  {lesson.level}
                </span>
              </div>

              <h3 className="text-lg font-bold text-slate-800 mb-2">{lesson.title}</h3>
              <p className="text-sm text-slate-500 mb-4 flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {lesson.duration}
              </p>

              <div className="flex items-center justify-between">
                <span className="text-sm text-slate-500">{lesson.questions.length} questions</span>
                <Button size="sm" className="bg-purple-600 hover:bg-purple-700 text-white rounded-full">
                  Start
                  <ChevronRight className="w-4 h-4 ml-1" />
                </Button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );
}
