import { useRef, useEffect } from 'react';
import { motion, useInView } from 'framer-motion';
import { Star, Circle, Diamond, Hexagon, Crown, Check, Lock } from 'lucide-react';
import { useUserProgress } from '@/hooks/useUserProgress';

const levels = [
  {
    id: 'A1',
    name: 'Beginner',
    description: 'Start your journey. Learn basic vocabulary, simple phrases, and everyday expressions.',
    icon: Star,
    color: 'from-green-400 to-green-600',
    lessons: 30,
    topics: ['Greetings', 'Numbers', 'Colors', 'Family', 'Food'],
  },
  {
    id: 'A2',
    name: 'Elementary',
    description: 'Build your foundation. Understand sentences and frequently used expressions.',
    icon: Circle,
    color: 'from-blue-400 to-blue-600',
    lessons: 35,
    topics: ['Past Tense', 'Shopping', 'Travel', 'Hobbies', 'Weather'],
  },
  {
    id: 'B1',
    name: 'Intermediate',
    description: 'Gain confidence. Deal with most situations while traveling and describe experiences.',
    icon: Diamond,
    color: 'from-yellow-400 to-orange-500',
    lessons: 40,
    topics: ['Opinions', 'News', 'Work', 'Dreams', 'Culture'],
  },
  {
    id: 'B2',
    name: 'Upper-Intermediate',
    description: 'Interact with fluency. Understand complex text and discuss technical topics.',
    icon: Hexagon,
    color: 'from-orange-400 to-red-500',
    lessons: 45,
    topics: ['Debate', 'Literature', 'Science', 'Politics', 'Art'],
  },
  {
    id: 'C1',
    name: 'Advanced',
    description: 'Master the language. Express ideas fluently and use language flexibly.',
    icon: Crown,
    color: 'from-purple-400 to-purple-600',
    lessons: 50,
    topics: ['Academic', 'Business', 'Idioms', 'Nuances', 'Mastery'],
  },
];

export default function LearningPath() {
  const containerRef = useRef<HTMLDivElement>(null);
  const pathRef = useRef<SVGPathElement>(null);
  const isInView = useInView(containerRef, { once: true, margin: '-100px' });
  const { progress } = useUserProgress();

  useEffect(() => {
    if (pathRef.current && isInView) {
      const length = pathRef.current.getTotalLength();
      pathRef.current.style.strokeDasharray = `${length}`;
      pathRef.current.style.strokeDashoffset = `${length}`;
      
      // Animate the path drawing
      pathRef.current.animate(
        [{ strokeDashoffset: length }, { strokeDashoffset: 0 }],
        { duration: 2000, easing: 'ease-out', fill: 'forwards' }
      );
    }
  }, [isInView]);

  const getLevelStatus = (levelId: string) => {
    const levelOrder = ['A1', 'A2', 'B1', 'B2', 'C1'];
    const currentIndex = levelOrder.indexOf(progress.level);
    const levelIndex = levelOrder.indexOf(levelId);
    
    if (levelIndex < currentIndex) return 'completed';
    if (levelIndex === currentIndex) return 'current';
    return 'locked';
  };

  return (
    <section ref={containerRef} className="py-20 bg-white relative overflow-hidden">
      {/* Background decoration */}
      <div className="absolute inset-0 bg-gradient-to-b from-slate-50 to-white" />
      
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="inline-block px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold mb-4">
            Structured Learning
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-slate-800 mb-4">
            Your Path to <span className="gradient-text">English Mastery</span>
          </h2>
          <p className="text-lg text-slate-600 max-w-2xl mx-auto">
            Follow our carefully designed curriculum from beginner to advanced. 
            Each level builds upon the previous one for steady progress.
          </p>
        </motion.div>

        {/* Path Container */}
        <div className="relative">
          {/* SVG Path - Desktop */}
          <svg
            className="absolute top-0 left-0 w-full h-full hidden lg:block"
            viewBox="0 0 1200 800"
            fill="none"
            preserveAspectRatio="none"
          >
            <path
              ref={pathRef}
              d="M 100 100 Q 300 100 400 200 Q 500 300 600 300 Q 700 300 800 400 Q 900 500 1100 500 Q 1000 600 900 700 Q 800 800 600 750"
              stroke="url(#gradient)"
              strokeWidth="4"
              strokeLinecap="round"
              fill="none"
              className="opacity-30"
            />
            <defs>
              <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                <stop offset="0%" stopColor="#7c3aed" />
                <stop offset="50%" stopColor="#3b82f6" />
                <stop offset="100%" stopColor="#fbbf24" />
              </linearGradient>
            </defs>
          </svg>

          {/* Level Cards */}
          <div className="grid lg:grid-cols-5 gap-6 lg:gap-4">
            {levels.map((level, index) => {
              const Icon = level.icon;
              const status = getLevelStatus(level.id);
              
              return (
                <motion.div
                  key={level.id}
                  initial={{ opacity: 0, y: 50, scale: 0.8 }}
                  whileInView={{ opacity: 1, y: 0, scale: 1 }}
                  viewport={{ once: true }}
                  transition={{ 
                    duration: 0.6, 
                    delay: index * 0.15,
                    type: 'spring',
                    stiffness: 100
                  }}
                  whileHover={{ scale: 1.05, y: -10 }}
                  className={`relative ${
                    index % 2 === 1 ? 'lg:mt-16' : ''
                  }`}
                >
                  <div
                    className={`bg-white rounded-3xl p-6 shadow-lg border-2 transition-all duration-300 ${
                      status === 'current'
                        ? 'border-purple-500 shadow-purple-200'
                        : status === 'completed'
                        ? 'border-green-400 shadow-green-100'
                        : 'border-slate-100'
                    }`}
                  >
                    {/* Level Badge */}
                    <div className="flex items-center justify-between mb-4">
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-bold ${
                          status === 'current'
                            ? 'bg-purple-100 text-purple-700'
                            : status === 'completed'
                            ? 'bg-green-100 text-green-700'
                            : 'bg-slate-100 text-slate-500'
                        }`}
                      >
                        {level.id}
                      </span>
                      {status === 'completed' && (
                        <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center">
                          <Check className="w-4 h-4 text-white" />
                        </div>
                      )}
                      {status === 'locked' && (
                        <Lock className="w-5 h-5 text-slate-400" />
                      )}
                    </div>

                    {/* Icon */}
                    <div
                      className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${level.color} flex items-center justify-center mb-4 ${
                        status === 'locked' ? 'opacity-50' : ''
                      }`}
                    >
                      <Icon className="w-7 h-7 text-white" />
                    </div>

                    {/* Content */}
                    <h3 className="text-lg font-bold text-slate-800 mb-2">{level.name}</h3>
                    <p className="text-sm text-slate-600 mb-4 line-clamp-3">{level.description}</p>

                    {/* Stats */}
                    <div className="flex items-center justify-between text-sm">
                      <span className="text-slate-500">{level.lessons} lessons</span>
                      <span className="text-slate-400">{level.topics.length} topics</span>
                    </div>

                    {/* Progress bar for current level */}
                    {status === 'current' && (
                      <div className="mt-4">
                        <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                          <motion.div
                            initial={{ width: 0 }}
                            animate={{ width: '45%' }}
                            transition={{ duration: 1, delay: 0.5 }}
                            className={`h-full bg-gradient-to-r ${level.color}`}
                          />
                        </div>
                        <p className="text-xs text-slate-500 mt-1">45% completed</p>
                      </div>
                    )}
                  </div>

                  {/* Connector dot */}
                  {index < levels.length - 1 && (
                    <div className="hidden lg:block absolute -right-3 top-1/2 transform -translate-y-1/2 z-10">
                      <motion.div
                        animate={{ scale: [1, 1.2, 1] }}
                        transition={{ duration: 2, repeat: Infinity, delay: index * 0.3 }}
                        className={`w-6 h-6 rounded-full border-4 border-white ${
                          status === 'completed' ? 'bg-green-500' : 'bg-slate-300'
                        }`}
                      />
                    </div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Current Progress Summary */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.5 }}
          className="mt-16 bg-gradient-to-r from-purple-600 to-blue-600 rounded-3xl p-8 text-white"
        >
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="text-2xl font-bold mb-2">Your Current Progress</h3>
              <p className="text-purple-100">
                You're at <span className="font-semibold">{progress.level}</span> level with{' '}
                <span className="font-semibold">{progress.xp} XP</span>. Keep going!
              </p>
            </div>
            <div className="flex items-center gap-4">
              <div className="text-center">
                <div className="text-3xl font-bold">{progress.streak}</div>
                <div className="text-sm text-purple-200">Day Streak</div>
              </div>
              <div className="w-px h-12 bg-white/30" />
              <div className="text-center">
                <div className="text-3xl font-bold">{progress.lessonsCompleted}</div>
                <div className="text-sm text-purple-200">Lessons Done</div>
              </div>
              <div className="w-px h-12 bg-white/30" />
              <div className="text-center">
                <div className="text-3xl font-bold">{progress.achievements.length}</div>
                <div className="text-sm text-purple-200">Achievements</div>
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
