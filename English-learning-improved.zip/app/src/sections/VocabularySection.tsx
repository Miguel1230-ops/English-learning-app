import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  ArrowLeft, 
  Sparkles, 
  Volume2, 
  RotateCcw,
  Trophy,
  Zap,
  BookOpen,
  Lightbulb,
  Shuffle,
  ChevronRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { toast } from 'sonner';
import { useUserProgress } from '@/hooks/useUserProgress';

interface VocabularySectionProps {
  onBack: () => void;
}

interface Word {
  id: number;
  word: string;
  meaning: string;
  example: string;
  pronunciation: string;
  level: string;
  category: string;
}

const vocabularyWords: Word[] = [
  { id: 1, word: 'beautiful', meaning: 'pleasing to the senses or mind', example: 'The sunset was beautiful.', pronunciation: '/ˈbjuːtɪfəl/', level: 'A1', category: 'Adjectives' },
  { id: 2, word: 'adventure', meaning: 'an exciting or unusual experience', example: 'We went on an adventure in the mountains.', pronunciation: '/ədˈventʃər/', level: 'A1', category: 'Nouns' },
  { id: 3, word: 'delicious', meaning: 'highly pleasant to the taste', example: 'This pizza is delicious!', pronunciation: '/dɪˈlɪʃəs/', level: 'A1', category: 'Adjectives' },
  { id: 4, word: 'important', meaning: 'of great significance or value', example: 'It is important to study every day.', pronunciation: '/ɪmˈpɔːtnt/', level: 'A1', category: 'Adjectives' },
  { id: 5, word: 'wonderful', meaning: 'inspiring delight or pleasure', example: 'We had a wonderful time at the party.', pronunciation: '/ˈwʌndəfl/', level: 'A1', category: 'Adjectives' },
  { id: 6, word: 'challenge', meaning: 'a task that tests someone\'s abilities', example: 'Learning a new language is a challenge.', pronunciation: '/ˈtʃælɪndʒ/', level: 'A2', category: 'Nouns' },
  { id: 7, word: 'confident', meaning: 'feeling sure about yourself', example: 'She felt confident about the exam.', pronunciation: '/ˈkɒnfɪdənt/', level: 'A2', category: 'Adjectives' },
  { id: 8, word: 'opportunity', meaning: 'a chance for advancement', example: 'This job is a great opportunity.', pronunciation: '/ˌɒpəˈtjuːnəti/', level: 'A2', category: 'Nouns' },
];

interface GameState {
  mode: 'flashcards' | 'matching' | 'quiz' | null;
  currentIndex: number;
  score: number;
  showAnswer: boolean;
  completed: boolean;
}

export default function VocabularySection({ onBack }: VocabularySectionProps) {
  const [gameState, setGameState] = useState<GameState>({
    mode: null,
    currentIndex: 0,
    score: 0,
    showAnswer: false,
    completed: false,
  });
  const [shuffledWords, setShuffledWords] = useState<Word[]>([]);
  const [matchedPairs, setMatchedPairs] = useState<number[]>([]);
  const [selectedCards, setSelectedCards] = useState<number[]>([]);
  const [quizOptions, setQuizOptions] = useState<string[]>([]);
  const { addXP, completeLesson } = useUserProgress();

  useEffect(() => {
    if (gameState.mode === 'matching') {
      const shuffled = [...vocabularyWords].sort(() => Math.random() - 0.5).slice(0, 6);
      setShuffledWords(shuffled);
      setMatchedPairs([]);
      setSelectedCards([]);
    } else if (gameState.mode === 'flashcards') {
      setShuffledWords([...vocabularyWords].sort(() => Math.random() - 0.5));
    } else if (gameState.mode === 'quiz') {
      const shuffled = [...vocabularyWords].sort(() => Math.random() - 0.5);
      setShuffledWords(shuffled);
      generateQuizOptions(shuffled[0]);
    }
  }, [gameState.mode]);

  const generateQuizOptions = (correctWord: Word) => {
    const wrongOptions = vocabularyWords
      .filter(w => w.id !== correctWord.id)
      .sort(() => Math.random() - 0.5)
      .slice(0, 3)
      .map(w => w.meaning);
    setQuizOptions([correctWord.meaning, ...wrongOptions].sort(() => Math.random() - 0.5));
  };

  const handleModeSelect = (mode: 'flashcards' | 'matching' | 'quiz') => {
    setGameState({
      mode,
      currentIndex: 0,
      score: 0,
      showAnswer: false,
      completed: false,
    });
  };

  const handleCardFlip = () => {
    setGameState(prev => ({ ...prev, showAnswer: !prev.showAnswer }));
  };

  const handleNextCard = () => {
    if (gameState.currentIndex < shuffledWords.length - 1) {
      setGameState(prev => ({
        ...prev,
        currentIndex: prev.currentIndex + 1,
        showAnswer: false,
      }));
    } else {
      setGameState(prev => ({ ...prev, completed: true }));
      addXP(30);
      completeLesson();
      toast.success('Flashcards completed! You earned 30 XP!');
    }
  };

  const handleMatchingCardClick = (cardId: number) => {
    if (selectedCards.includes(cardId) || matchedPairs.includes(cardId)) return;

    const newSelected = [...selectedCards, cardId];
    setSelectedCards(newSelected);

    if (newSelected.length === 2) {
      const [first, second] = newSelected;
      const firstWordId = Math.floor(first / 2);
      const secondWordId = Math.floor(second / 2);

      if (firstWordId === secondWordId && first !== second) {
        setMatchedPairs([...matchedPairs, first, second]);
        setGameState(prev => ({ ...prev, score: prev.score + 10 }));
        toast.success('Match found! +10 XP');
      }

      setTimeout(() => setSelectedCards([]), 1000);
    }
  };

  const handleQuizAnswer = (answer: string) => {
    const correct = answer === shuffledWords[gameState.currentIndex].meaning;
    
    if (correct) {
      setGameState(prev => ({ ...prev, score: prev.score + 15 }));
      toast.success('Correct! +15 XP');
    } else {
      toast.error('Not quite!');
    }

    setTimeout(() => {
      if (gameState.currentIndex < shuffledWords.length - 1) {
        const nextIndex = gameState.currentIndex + 1;
        setGameState(prev => ({ ...prev, currentIndex: nextIndex }));
        generateQuizOptions(shuffledWords[nextIndex]);
      } else {
        setGameState(prev => ({ ...prev, completed: true }));
        addXP(gameState.score + (correct ? 15 : 0));
        completeLesson();
        toast.success('Quiz completed!');
      }
    }, 1000);
  };

  const resetGame = () => {
    setGameState({
      mode: null,
      currentIndex: 0,
      score: 0,
      showAnswer: false,
      completed: false,
    });
    setMatchedPairs([]);
    setSelectedCards([]);
  };

  // Flashcards Mode
  if (gameState.mode === 'flashcards' && !gameState.completed) {
    const currentWord = shuffledWords[gameState.currentIndex];
    
    return (
      <div className="min-h-screen bg-slate-50 pt-20 pb-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-2xl">
          <div className="flex items-center gap-4 mb-8">
            <button onClick={resetGame} className="p-2 rounded-full hover:bg-slate-200 transition-colors">
              <ArrowLeft className="w-6 h-6" />
            </button>
            <div>
              <h1 className="text-2xl font-bold text-slate-800">Flashcards</h1>
              <p className="text-slate-500">Card {gameState.currentIndex + 1} of {shuffledWords.length}</p>
            </div>
          </div>

          <Progress value={((gameState.currentIndex + 1) / shuffledWords.length) * 100} className="mb-6" />

          <motion.div
            className="relative h-80 cursor-pointer"
            onClick={handleCardFlip}
          >
            <AnimatePresence mode="wait">
              {!gameState.showAnswer ? (
                <motion.div
                  key="front"
                  initial={{ rotateY: 90 }}
                  animate={{ rotateY: 0 }}
                  exit={{ rotateY: -90 }}
                  transition={{ duration: 0.3 }}
                  className="absolute inset-0 bg-gradient-to-br from-purple-600 to-blue-600 rounded-3xl p-8 flex flex-col items-center justify-center text-white shadow-xl"
                >
                  <span className="text-sm uppercase tracking-wider opacity-70 mb-4">Word</span>
                  <h2 className="text-4xl font-bold mb-4">{currentWord?.word}</h2>
                  <p className="text-lg opacity-80">{currentWord?.pronunciation}</p>
                  <p className="text-sm mt-8 opacity-60">Tap to flip</p>
                </motion.div>
              ) : (
                <motion.div
                  key="back"
                  initial={{ rotateY: 90 }}
                  animate={{ rotateY: 0 }}
                  exit={{ rotateY: -90 }}
                  transition={{ duration: 0.3 }}
                  className="absolute inset-0 bg-white rounded-3xl p-8 flex flex-col items-center justify-center shadow-xl border border-slate-100"
                >
                  <span className="text-sm uppercase tracking-wider text-slate-400 mb-4">Meaning</span>
                  <p className="text-2xl text-slate-800 text-center mb-4">{currentWord?.meaning}</p>
                  <div className="bg-slate-50 rounded-xl p-4 max-w-sm">
                    <p className="text-slate-600 italic">"{currentWord?.example}"</p>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      toast.info(`Pronunciation: ${currentWord?.pronunciation}`);
                    }}
                    className="mt-4 p-2 rounded-full bg-purple-100 text-purple-600 hover:bg-purple-200 transition-colors"
                  >
                    <Volume2 className="w-5 h-5" />
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </motion.div>

          <div className="flex justify-center mt-8">
            <Button onClick={handleNextCard} className="bg-purple-600 hover:bg-purple-700 text-white rounded-full px-8">
              Next Card
              <ChevronRight className="w-4 h-4 ml-2" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  // Matching Game Mode
  if (gameState.mode === 'matching' && !gameState.completed) {
    const allMatched = matchedPairs.length === 12;
    
    if (allMatched && !gameState.completed) {
      setTimeout(() => {
        setGameState(prev => ({ ...prev, completed: true }));
        addXP(gameState.score);
        completeLesson();
        toast.success('All matches found! Great job!');
      }, 500);
    }

    const cards = [...shuffledWords.map(w => ({ id: w.id * 2, text: w.word, type: 'word' as const })),
                   ...shuffledWords.map(w => ({ id: w.id * 2 + 1, text: w.meaning, type: 'meaning' as const }))]
                  .sort(() => Math.random() - 0.5);

    return (
      <div className="min-h-screen bg-slate-50 pt-20 pb-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-3xl">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <button onClick={resetGame} className="p-2 rounded-full hover:bg-slate-200 transition-colors">
                <ArrowLeft className="w-6 h-6" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-slate-800">Word Matching</h1>
                <p className="text-slate-500">Match words with their meanings</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-purple-600">{gameState.score}</p>
              <p className="text-sm text-slate-500">XP</p>
            </div>
          </div>

          <Progress value={(matchedPairs.length / 12) * 100} className="mb-6" />

          <div className="grid grid-cols-3 gap-4">
            {cards.map((card) => {
              const isMatched = matchedPairs.includes(card.id);
              const isSelected = selectedCards.includes(card.id);
              
              return (
                <motion.button
                  key={card.id}
                  onClick={() => handleMatchingCardClick(card.id)}
                  disabled={isMatched}
                  whileHover={!isMatched ? { scale: 1.05 } : {}}
                  whileTap={!isMatched ? { scale: 0.95 } : {}}
                  className={`h-24 rounded-xl p-3 text-sm font-medium transition-all ${
                    isMatched
                      ? 'bg-green-100 text-green-700 border-2 border-green-300'
                      : isSelected
                      ? 'bg-purple-100 text-purple-700 border-2 border-purple-400'
                      : 'bg-white text-slate-700 border-2 border-slate-200 hover:border-purple-300'
                  }`}
                >
                  <span className="line-clamp-3">{card.text}</span>
                </motion.button>
              );
            })}
          </div>
        </div>
      </div>
    );
  }

  // Quiz Mode
  if (gameState.mode === 'quiz' && !gameState.completed) {
    const currentWord = shuffledWords[gameState.currentIndex];

    return (
      <div className="min-h-screen bg-slate-50 pt-20 pb-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-2xl">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-4">
              <button onClick={resetGame} className="p-2 rounded-full hover:bg-slate-200 transition-colors">
                <ArrowLeft className="w-6 h-6" />
              </button>
              <div>
                <h1 className="text-2xl font-bold text-slate-800">Vocabulary Quiz</h1>
                <p className="text-slate-500">Question {gameState.currentIndex + 1} of {shuffledWords.length}</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-2xl font-bold text-purple-600">{gameState.score}</p>
              <p className="text-sm text-slate-500">XP</p>
            </div>
          </div>

          <Progress value={((gameState.currentIndex + 1) / shuffledWords.length) * 100} className="mb-6" />

          <div className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100">
            <p className="text-lg text-slate-600 mb-2">What is the meaning of:</p>
            <h2 className="text-3xl font-bold text-slate-800 mb-8">{currentWord?.word}</h2>

            <div className="space-y-3">
              {quizOptions.map((option) => (
                <button
                  key={option}
                  onClick={() => handleQuizAnswer(option)}
                  className="w-full p-4 rounded-xl border-2 border-slate-200 text-left hover:border-purple-400 hover:bg-purple-50 transition-all"
                >
                  {option}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Completion Screen
  if (gameState.completed) {
    return (
      <div className="min-h-screen bg-slate-50 pt-20 pb-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-md">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl p-8 shadow-sm border border-slate-100 text-center"
          >
            <div className="w-20 h-20 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Trophy className="w-10 h-10 text-yellow-600" />
            </div>
            <h2 className="text-2xl font-bold text-slate-800 mb-2">Activity Completed!</h2>
            <p className="text-slate-600 mb-6">
              You earned <span className="font-bold text-purple-600">{gameState.score} XP</span>!
            </p>
            <div className="flex gap-4 justify-center">
              <Button onClick={resetGame} variant="outline" className="rounded-full">
                <RotateCcw className="w-4 h-4 mr-2" />
                Play Again
              </Button>
              <Button onClick={onBack} className="bg-purple-600 hover:bg-purple-700 text-white rounded-full">
                Back to Menu
              </Button>
            </div>
          </motion.div>
        </div>
      </div>
    );
  }

  // Main Menu
  return (
    <div className="min-h-screen bg-slate-50 pt-20 pb-12">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <button onClick={onBack} className="p-2 rounded-full hover:bg-slate-200 transition-colors">
            <ArrowLeft className="w-6 h-6" />
          </button>
          <div>
            <h1 className="text-3xl font-bold text-slate-800">Vocabulary Builder</h1>
            <p className="text-slate-600">Learn new words with fun activities</p>
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-3 gap-4 mb-8">
          <div className="bg-white rounded-2xl p-4 text-center shadow-sm">
            <BookOpen className="w-6 h-6 text-purple-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-slate-800">{vocabularyWords.length}</p>
            <p className="text-sm text-slate-500">Words</p>
          </div>
          <div className="bg-white rounded-2xl p-4 text-center shadow-sm">
            <Zap className="w-6 h-6 text-yellow-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-slate-800">3</p>
            <p className="text-sm text-slate-500">Games</p>
          </div>
          <div className="bg-white rounded-2xl p-4 text-center shadow-sm">
            <Trophy className="w-6 h-6 text-green-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-slate-800">Daily</p>
            <p className="text-sm text-slate-500">Challenge</p>
          </div>
        </div>

        {/* Game Modes */}
        <h2 className="text-xl font-bold text-slate-800 mb-4">Choose an Activity</h2>
        <div className="grid md:grid-cols-3 gap-6">
          <motion.div
            whileHover={{ y: -4 }}
            onClick={() => handleModeSelect('flashcards')}
            className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 cursor-pointer hover:shadow-md transition-all"
          >
            <div className="w-14 h-14 bg-purple-100 rounded-xl flex items-center justify-center mb-4">
              <Shuffle className="w-7 h-7 text-purple-600" />
            </div>
            <h3 className="text-lg font-bold text-slate-800 mb-2">Flashcards</h3>
            <p className="text-sm text-slate-600 mb-4">Flip cards to learn words and meanings</p>
            <div className="flex items-center text-purple-600 text-sm font-medium">
              Start Learning
              <ChevronRight className="w-4 h-4 ml-1" />
            </div>
          </motion.div>

          <motion.div
            whileHover={{ y: -4 }}
            onClick={() => handleModeSelect('matching')}
            className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 cursor-pointer hover:shadow-md transition-all"
          >
            <div className="w-14 h-14 bg-blue-100 rounded-xl flex items-center justify-center mb-4">
              <Sparkles className="w-7 h-7 text-blue-600" />
            </div>
            <h3 className="text-lg font-bold text-slate-800 mb-2">Word Match</h3>
            <p className="text-sm text-slate-600 mb-4">Match words with their definitions</p>
            <div className="flex items-center text-blue-600 text-sm font-medium">
              Play Now
              <ChevronRight className="w-4 h-4 ml-1" />
            </div>
          </motion.div>

          <motion.div
            whileHover={{ y: -4 }}
            onClick={() => handleModeSelect('quiz')}
            className="bg-white rounded-2xl p-6 shadow-sm border border-slate-100 cursor-pointer hover:shadow-md transition-all"
          >
            <div className="w-14 h-14 bg-green-100 rounded-xl flex items-center justify-center mb-4">
              <Lightbulb className="w-7 h-7 text-green-600" />
            </div>
            <h3 className="text-lg font-bold text-slate-800 mb-2">Vocabulary Quiz</h3>
            <p className="text-sm text-slate-600 mb-4">Test your knowledge with a quiz</p>
            <div className="flex items-center text-green-600 text-sm font-medium">
              Take Quiz
              <ChevronRight className="w-4 h-4 ml-1" />
            </div>
          </motion.div>
        </div>

        {/* Word of the Day */}
        <div className="mt-8 bg-gradient-to-r from-purple-600 to-blue-600 rounded-2xl p-6 text-white">
          <div className="flex items-center gap-2 mb-3">
            <Sparkles className="w-5 h-5" />
            <h3 className="font-bold">Word of the Day</h3>
          </div>
          <div className="flex items-center gap-3 mb-2">
            <span className="text-2xl font-bold">serendipity</span>
            <button className="p-1 rounded-full bg-white/20 hover:bg-white/30 transition-colors">
              <Volume2 className="w-4 h-4" />
            </button>
          </div>
          <p className="text-purple-100 text-sm mb-2">/ˌserənˈdɪpəti/ • noun</p>
          <p className="text-white/90">The occurrence of events by chance in a happy or beneficial way.</p>
          <p className="text-purple-100 text-sm mt-2 italic">"Finding this restaurant was pure serendipity."</p>
        </div>
      </div>
    </div>
  );
}
