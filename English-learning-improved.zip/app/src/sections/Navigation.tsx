import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { BookOpen, Headphones, MessageCircle, PenTool, Home, Menu, X, Sparkles } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface NavigationProps {
  currentView: string;
  onNavigate: (view: 'home' | 'dashboard' | 'reading' | 'grammar' | 'vocabulary' | 'listening' | 'speaking') => void;
}

export default function Navigation({ currentView, onNavigate }: NavigationProps) {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { id: 'home', label: 'Home', icon: Home },
    { id: 'reading', label: 'Reading', icon: BookOpen },
    { id: 'grammar', label: 'Grammar', icon: PenTool },
    { id: 'vocabulary', label: 'Vocabulary', icon: Sparkles },
    { id: 'listening', label: 'Listening', icon: Headphones },
    { id: 'speaking', label: 'Speaking', icon: MessageCircle },
  ];

  const isActive = (id: string) => currentView === id || (id === 'home' && currentView === 'dashboard');

  return (
    <>
      <motion.nav
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.8, ease: [0.68, -0.6, 0.32, 1.6] }}
        className={`fixed top-4 left-1/2 -translate-x-1/2 z-50 transition-all duration-500 ${
          isScrolled
            ? 'glass rounded-full px-4 py-2 shadow-lg'
            : 'bg-transparent px-8 py-4'
        }`}
      >
        <div className="flex items-center gap-6">
          {/* Logo */}
          <motion.div
            className="flex items-center gap-2 cursor-pointer"
            onClick={() => onNavigate('home')}
            whileHover={{ scale: 1.05 }}
          >
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-600 to-blue-500 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className={`font-bold text-lg hidden sm:block ${isScrolled ? 'text-slate-800' : 'text-slate-800'}`}>
              EnglishMastery
            </span>
          </motion.div>

          {/* Desktop Links */}
          <div className="hidden md:flex items-center gap-1">
            {navLinks.map((link, index) => {
              const Icon = link.icon;
              return (
                <motion.button
                  key={link.id}
                  initial={{ opacity: 0, y: -20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.2 + index * 0.1 }}
                  onClick={() => onNavigate(link.id as any)}
                  className={`relative px-4 py-2 rounded-full flex items-center gap-2 transition-all duration-300 ${
                    isActive(link.id)
                      ? 'bg-purple-100 text-purple-700'
                      : 'hover:bg-slate-100 text-slate-600'
                  }`}
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                >
                  <Icon className="w-4 h-4" />
                  <span className="text-sm font-medium">{link.label}</span>
                  {isActive(link.id) && (
                    <motion.div
                      layoutId="activeNav"
                      className="absolute inset-0 bg-purple-100 rounded-full -z-10"
                      transition={{ type: 'spring', bounce: 0.2, duration: 0.6 }}
                    />
                  )}
                </motion.button>
              );
            })}
          </div>

          {/* CTA Button */}
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            transition={{ delay: 0.6, type: 'spring', stiffness: 200 }}
          >
            <Button
              onClick={() => onNavigate('dashboard')}
              className="hidden sm:flex bg-gradient-to-r from-purple-600 to-blue-500 text-white rounded-full px-6 hover:shadow-lg hover:shadow-purple-500/30 transition-all duration-300"
            >
              Start Learning
            </Button>
          </motion.div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="md:hidden p-2 rounded-full hover:bg-slate-100"
          >
            {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </motion.nav>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-20 left-4 right-4 z-40 glass rounded-2xl p-4 md:hidden"
          >
            <div className="flex flex-col gap-2">
              {navLinks.map((link) => {
                const Icon = link.icon;
                return (
                  <button
                    key={link.id}
                    onClick={() => {
                      onNavigate(link.id as any);
                      setIsMobileMenuOpen(false);
                    }}
                    className={`flex items-center gap-3 px-4 py-3 rounded-xl transition-all ${
                      isActive(link.id)
                        ? 'bg-purple-100 text-purple-700'
                        : 'hover:bg-slate-100 text-slate-600'
                    }`}
                  >
                    <Icon className="w-5 h-5" />
                    <span className="font-medium">{link.label}</span>
                  </button>
                );
              })}
              <Button
                onClick={() => {
                  onNavigate('dashboard');
                  setIsMobileMenuOpen(false);
                }}
                className="mt-2 bg-gradient-to-r from-purple-600 to-blue-500 text-white rounded-xl"
              >
                Start Learning
              </Button>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
