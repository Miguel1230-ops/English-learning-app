import React, { createContext, useContext, useEffect, useMemo, useState, useCallback } from 'react';

export type EnglishLevel = 'A1' | 'A2' | 'B1' | 'B2' | 'C1';

export interface UserProgress {
  level: EnglishLevel;
  xp: number;
  streak: number;
  lessonsCompleted: number;
  totalLessons: number;
  achievements: string[];
  lastActiveDate: string | null;
}

interface UserProgressContextType {
  progress: UserProgress;
  addXP: (amount: number) => void;
  completeLesson: (lessonId?: string) => void;
  updateStreak: () => void;
  addAchievement: (achievement: string) => void;
  setLevel: (level: EnglishLevel) => void;
  resetProgress: () => void;
}

const STORAGE_KEY = 'english-mastery-progress-v2';

const defaultProgress: UserProgress = {
  level: 'A1',
  xp: 0,
  streak: 1,
  lessonsCompleted: 0,
  totalLessons: 150,
  achievements: ['Welcome Learner'],
  lastActiveDate: null,
};

const UserProgressContext = createContext<UserProgressContextType | undefined>(undefined);

function deriveLevelFromXP(xp: number): EnglishLevel {
  if (xp >= 1400) return 'C1';
  if (xp >= 900) return 'B2';
  if (xp >= 450) return 'B1';
  if (xp >= 150) return 'A2';
  return 'A1';
}

function safeLoadProgress(): UserProgress {
  if (typeof window === 'undefined') return defaultProgress;

  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return defaultProgress;

    const parsed = JSON.parse(raw) as Partial<UserProgress>;
    return {
      ...defaultProgress,
      ...parsed,
      level: deriveLevelFromXP(Number(parsed.xp ?? 0)),
      achievements: Array.isArray(parsed.achievements) && parsed.achievements.length > 0
        ? Array.from(new Set(parsed.achievements))
        : defaultProgress.achievements,
    };
  } catch {
    return defaultProgress;
  }
}

export function UserProgressProvider({ children }: { children: React.ReactNode }) {
  const [progress, setProgress] = useState<UserProgress>(() => safeLoadProgress());

  useEffect(() => {
    if (typeof window === 'undefined') return;
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  }, [progress]);

  const addXP = useCallback((amount: number) => {
    if (!Number.isFinite(amount) || amount <= 0) return;

    setProgress(prev => {
      const nextXP = prev.xp + amount;
      return {
        ...prev,
        xp: nextXP,
        level: deriveLevelFromXP(nextXP),
        lastActiveDate: new Date().toISOString(),
      };
    });
  }, []);

  const completeLesson = useCallback((_lessonId?: string) => {
    setProgress(prev => ({
      ...prev,
      lessonsCompleted: prev.lessonsCompleted + 1,
      lastActiveDate: new Date().toISOString(),
    }));
  }, []);

  const updateStreak = useCallback(() => {
    setProgress(prev => ({
      ...prev,
      streak: prev.streak + 1,
      lastActiveDate: new Date().toISOString(),
    }));
  }, []);

  const addAchievement = useCallback((achievement: string) => {
    const trimmed = achievement.trim();
    if (!trimmed) return;

    setProgress(prev => {
      if (prev.achievements.includes(trimmed)) return prev;
      return {
        ...prev,
        achievements: [...prev.achievements, trimmed],
        lastActiveDate: new Date().toISOString(),
      };
    });
  }, []);

  const setLevel = useCallback((level: EnglishLevel) => {
    setProgress(prev => ({
      ...prev,
      level,
      lastActiveDate: new Date().toISOString(),
    }));
  }, []);

  const resetProgress = useCallback(() => {
    setProgress(defaultProgress);
  }, []);

  const value = useMemo(
    () => ({ progress, addXP, completeLesson, updateStreak, addAchievement, setLevel, resetProgress }),
    [progress, addXP, completeLesson, updateStreak, addAchievement, setLevel, resetProgress]
  );

  return (
    <UserProgressContext.Provider value={value}>
      {children}
    </UserProgressContext.Provider>
  );
}

export function useUserProgress() {
  const context = useContext(UserProgressContext);
  if (context === undefined) {
    throw new Error('useUserProgress must be used within a UserProgressProvider');
  }
  return context;
}
